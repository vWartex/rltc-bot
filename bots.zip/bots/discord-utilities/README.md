# Discord Server Utilities Bot

A Node.js Discord bot with these slash commands:

- `/ping` — check the bot connection and whether its bot account has joined the current server.
- `/poll` — post a poll with two to four choices. Each member can change or remove their vote.
- `/remind` — schedule a reminder in the current server channel, from 1 minute to 7 days ahead.
- `/role` — add or remove a role for yourself.
- `/setup-verify` — administrators post a server verification panel.
- `/ban`, `/kick`, `/timeout`, `/tempban`, and `/unban` — moderator actions recorded as numbered cases.
- `/case` — view a user's moderation history.
- `/level` — view a player's XP, level, and Rocket League rank.
- `/leaderboard` — compare the server's highest levels and Credit balances.
- `/profile` — view a player's level, rank, Credits, favorite vehicle, and shop inventory.
- `/balance [user]` — view your Credits or another member's balance.
- `/shop` — browse Rocket League collectibles and passes.
- `/buy item` — purchase an item with Credits; purchases appear in `/profile`.
- `/nick user nickname` — use an active Nickname Troll pass to change a server member's nickname.
- `/vehicle` — set or clear your favorite vehicle for `/profile`.
- `/daily` — claim 500 Credits once every 24 hours.
- `/work` — earn 100–500 Credits every 30 minutes.
- `/crime` — take a 50/50 risk to gain 200–700 or lose up to 150–400 Credits every 30 minutes.
- `/help` — list the commands.

Chat messages award 15–25 XP, at most once per user per minute. Each level takes 100 total XP; ranks follow the Bronze-to-Grand-Champion level ranges shown in `/level`.

Polls, reminders, moderation cases, temporary-ban schedules, player XP, Credits, vehicles, and cooldown timestamps are stored in `data/bot-state.json` and survive process restarts. Expired temporary bans are checked at startup and every 15 seconds. The data directory is excluded from Git. XP tracking does not read message contents.

The AI `/question` command is not enabled yet; AI access was deferred until a provider and cost setup are chosen.

The Rocket League shop has four one-time collectibles or passes: Custom Roll Color (2,500 Credits), Fennec Body (5,000), Titanium White Octane (15,000), and Nickname Troll (3,500). The Nickname Troll pass is active for 24 hours and can be used with `/nick`; the bot needs **Manage Nicknames**, and Discord's role hierarchy may prevent changes to some members. Custom Roll Color purchases require moderator assistance.

`/setup-verify` posts a persistent verification panel. The server must have an `Un-Verified` role; the bot creates the gray `Verified` role on the first eligible click, grants it, and removes `Un-Verified`. Panel settings are saved in `data/bot-state.json`. The bot needs **Manage Roles**, with its role above both verification roles and the members being verified.

## Discord setup

1. In the [Discord Developer Portal](https://discord.com/developers/applications), create an application and add a bot.
2. Copy the bot token into Replit Secrets as `DISCORD_TOKEN`. Never commit or post the token.
3. In **Installation → Installation Contexts**, enable **Guild Install**. User Install can stay enabled too, but it does not add the bot account to a server.
4. Under **Installation → Default Install Settings → Guild Install**, select both `applications.commands` and `bot`. Choose **View Channels**, **Send Messages**, **Embed Links**, **Manage Roles**, and **Manage Nicknames**. For moderation, also grant **Kick Members**, **Ban Members**, and **Moderate Members**. Add **Send Messages in Threads** if you want to use the bot in threads.
5. Use the Guild Install link or the OAuth2 URL Generator with both scopes, choose **Add to Server**, select the target server, and authorize. Installing only to a user can make commands work without adding the bot as a server member.
6. In **Server Settings → Roles**, move the bot's role above every role members should be able to self-assign or moderate.
7. Start the **Discord Utilities Bot** workflow. It registers the slash commands when it connects. Global command updates may take a little while to appear in Discord.

To confirm membership, run `/ping` in the target server. Its response says whether the bot account has joined that server.

Moderation commands also check the acting member's permission at runtime. `/ban`, `/tempban`, and `/unban` require **Ban Members**; `/kick` requires **Kick Members**; `/timeout` requires **Moderate Members**. `/case` is available to administrators or members with **Moderate Members**, **Ban Members**, or **Kick Members**. The bot's role must be high enough to act on the target member. Each attempted action gets a sequential case number, included in Discord's audit log reason when Discord supports it.

For Discord's explanation of the two install contexts, see [Choosing installation contexts](https://docs.discord.com/developers/quick-start/getting-started#choosing-installation-contexts).

## Local commands

- `pnpm --filter @workspace/discord-utilities run dev` — run with file watching.
- `pnpm --filter @workspace/discord-utilities run start` — run the bot.
- `pnpm --filter @workspace/discord-utilities run test` — test local storage and cooldown behavior.
- `pnpm --filter @workspace/discord-utilities run typecheck` — check TypeScript.