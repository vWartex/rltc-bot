(() => {
  "use strict";

  const REFRESH_INTERVAL = 30_000;
  const levelRows = document.getElementById("level-rows");
  const creditsRows = document.getElementById("credits-rows");
  const levelState = document.getElementById("level-state");
  const creditsState = document.getElementById("credits-state");
  const leaderboardError = document.getElementById("leaderboard-error");
  const badgeList = document.getElementById("badge-list");
  const badgeState = document.getElementById("badge-state");
  const refreshButton = document.getElementById("refresh-button");
  const updatedAt = document.getElementById("updated-at");
  const guildName = document.getElementById("guild-name");
  let leaderboardRequestActive = false;
  let lastLeaderboard = null;

  const numberFormat = new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 });

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function safeAvatarUrl(value) {
    if (typeof value !== "string" || !value.trim()) return "";
    try {
      const url = new URL(value, window.location.origin);
      return url.protocol === "https:" || url.protocol === "http:" ? url.href : "";
    } catch {
      return "";
    }
  }

  function initialsFor(name) {
    const parts = String(name || "?").trim().split(/\s+/).filter(Boolean);
    return (parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : parts[0]?.slice(0, 2) || "?").toUpperCase();
  }

  function createAvatar(member) {
    const avatarUrl = safeAvatarUrl(member.avatarUrl);
    if (avatarUrl) {
      const image = makeElement("img", "avatar");
      image.src = avatarUrl;
      image.alt = "";
      image.loading = "lazy";
      image.referrerPolicy = "no-referrer";
      image.addEventListener("error", () => {
        const fallback = makeElement("span", "avatar avatar-fallback", initialsFor(member.displayName));
        fallback.setAttribute("aria-hidden", "true");
        image.replaceWith(fallback);
      }, { once: true });
      return image;
    }
    const fallback = makeElement("span", "avatar avatar-fallback", initialsFor(member.displayName));
    fallback.setAttribute("aria-hidden", "true");
    return fallback;
  }

  function makeSkeletonRows(tbody, count, cells) {
    tbody.replaceChildren();
    for (let rowIndex = 0; rowIndex < count; rowIndex += 1) {
      const row = document.createElement("tr");
      row.className = "skeleton-row";
      for (let cellIndex = 0; cellIndex < cells; cellIndex += 1) {
        const cell = document.createElement("td");
        if (cellIndex === cells - 1) cell.className = "numeric";
        const bar = makeElement("span", `skeleton-bar${cellIndex === 0 || cellIndex === cells - 1 ? " short" : ""}`);
        bar.setAttribute("aria-hidden", "true");
        cell.append(bar);
        row.append(cell);
      }
      tbody.append(row);
    }
  }

  function renderMemberRows(tbody, members, mode) {
    tbody.replaceChildren();
    for (const [index, member] of members.slice(0, 5).entries()) {
      const row = document.createElement("tr");
      const rank = makeElement("td", "rank-cell");
      const rankNumber = makeElement("span", index < 3 ? "rank-number" : "", String(member.rank ?? index + 1).padStart(2, "0"));
      rank.append(rankNumber);
      row.append(rank);

      const player = makeElement("td", "player-cell");
      const playerInfo = makeElement("div", "player-info");
      playerInfo.append(createAvatar(member));
      const name = makeElement("span", "player-name", member.displayName || "Unknown player");
      playerInfo.append(name);
      player.append(playerInfo);
      row.append(player);

      const stat = makeElement("td", "numeric");
      stat.append(makeElement("span", "stat-value", numberFormat.format(mode === "level" ? Number(member.level) || 0 : Number(member.credits) || 0)));
      row.append(stat);
      if (mode === "level") {
        const xp = makeElement("td", "numeric xp-column");
        xp.append(makeElement("span", "xp-value", numberFormat.format(Number(member.xp) || 0)));
        row.append(xp);
      }
      tbody.append(row);
    }
  }

  function setTableState(element, message, retry) {
    element.replaceChildren();
    element.append(document.createTextNode(message));
    if (retry) {
      const button = makeElement("button", "", "Try again");
      button.type = "button";
      button.addEventListener("click", fetchLeaderboard);
      element.append(button);
    }
    element.hidden = false;
  }

  function validLeaderboard(data) {
    return data && typeof data === "object" && Array.isArray(data.level) && Array.isArray(data.credits);
  }

  async function fetchLeaderboard() {
    if (leaderboardRequestActive) return;
    leaderboardRequestActive = true;
    refreshButton.disabled = true;
    refreshButton.classList.add("is-loading");
    refreshButton.setAttribute("aria-busy", "true");
    leaderboardError.hidden = true;
    if (!lastLeaderboard) {
      makeSkeletonRows(levelRows, 3, 4);
      makeSkeletonRows(creditsRows, 3, 3);
      levelRows.setAttribute("aria-busy", "true");
      creditsRows.setAttribute("aria-busy", "true");
    }
    try {
      const response = await fetch("/api/leaderboard", { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error(`Leaderboard request failed (${response.status}).`);
      const data = await response.json();
      if (!validLeaderboard(data)) throw new Error("The leaderboard response was not in the expected format.");

      lastLeaderboard = data;
      renderMemberRows(levelRows, data.level, "level");
      renderMemberRows(creditsRows, data.credits, "credits");
      levelRows.setAttribute("aria-busy", "false");
      creditsRows.setAttribute("aria-busy", "false");
      guildName.textContent = typeof data.guildName === "string" && data.guildName.trim() ? data.guildName : "Community server";
      const parsedDate = typeof data.updatedAt === "string" ? new Date(data.updatedAt) : null;
      updatedAt.textContent = parsedDate && !Number.isNaN(parsedDate.getTime())
        ? parsedDate.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })
        : "Just now";
      updatedAt.dateTime = parsedDate && !Number.isNaN(parsedDate.getTime()) ? parsedDate.toISOString() : new Date().toISOString();
      levelState.hidden = data.level.length > 0;
      creditsState.hidden = data.credits.length > 0;
      if (data.level.length === 0) setTableState(levelState, "No level standings yet. Chat in Discord to earn XP.");
      if (data.credits.length === 0) setTableState(creditsState, "No Credit standings yet. Claim Credits in Discord to get on the board.");
    } catch (error) {
      if (lastLeaderboard) {
        leaderboardError.replaceChildren(
          document.createTextNode(`Refresh failed. Showing the last loaded standings. ${error instanceof Error ? error.message : ""} `),
        );
        const retry = makeElement("button", "", "Retry now");
        retry.type = "button";
        retry.addEventListener("click", fetchLeaderboard);
        leaderboardError.append(retry);
        leaderboardError.hidden = false;
      } else {
        levelRows.replaceChildren();
        creditsRows.replaceChildren();
        levelRows.setAttribute("aria-busy", "false");
        creditsRows.setAttribute("aria-busy", "false");
        setTableState(levelState, "Standings could not be loaded. Check your connection and try again.", true);
        setTableState(creditsState, "Standings could not be loaded. Check your connection and try again.", true);
        guildName.textContent = "Connection unavailable";
        updatedAt.textContent = "Update unavailable";
      }
    } finally {
      leaderboardRequestActive = false;
      refreshButton.disabled = false;
      refreshButton.classList.remove("is-loading");
      refreshButton.removeAttribute("aria-busy");
    }
  }

  function validBadge(badge) {
    return badge && typeof badge === "object" &&
      typeof badge.id === "string" && typeof badge.name === "string" &&
      typeof badge.emoji === "string" && typeof badge.description === "string" &&
      typeof badge.acquisition === "string";
  }

  function renderBadges(badges) {
    badgeList.replaceChildren();
    for (const [index, badge] of badges.entries()) {
      if (!validBadge(badge)) continue;
      const card = makeElement("article", "badge-card");
      card.style.animationDelay = `${Math.min(index * 45, 225)}ms`;
      const emoji = makeElement("span", "badge-emoji", badge.emoji);
      emoji.setAttribute("aria-hidden", "true");
      const heading = makeElement("h3", "badge-name", badge.name);
      const description = makeElement("p", "badge-description", badge.description);
      const meta = makeElement("div", "badge-meta");
      const acquisition = makeElement("span", "badge-acquisition", badge.acquisition);
      acquisition.setAttribute("aria-label", `How to acquire: ${badge.acquisition}`);
      meta.append(acquisition);
      if (badge.cost === null) {
        meta.append(makeElement("span", "badge-cost", "SPECIAL AWARD"));
      } else if (typeof badge.cost === "number" && Number.isFinite(badge.cost)) {
        meta.append(makeElement("span", "badge-cost", `${numberFormat.format(badge.cost)} CREDITS`));
      }
      card.append(emoji, heading, description, meta);
      badgeList.append(card);
    }
    badgeList.setAttribute("aria-busy", "false");
  }

  async function fetchBadges() {
    badgeList.setAttribute("aria-busy", "true");
    try {
      const response = await fetch("/api/badges", { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error(`Badge request failed (${response.status}).`);
      const data = await response.json();
      if (!data || !Array.isArray(data.badges)) throw new Error("The badge response was not in the expected format.");
      const badges = data.badges.filter(validBadge);
      renderBadges(badges);
      if (badges.length === 0) {
        badgeState.textContent = "No badges are available right now.";
        badgeState.hidden = false;
      } else {
        badgeState.hidden = true;
      }
    } catch {
      badgeList.replaceChildren();
      badgeList.setAttribute("aria-busy", "false");
      badgeState.replaceChildren(document.createTextNode("The badge index could not be loaded. "));
      const retry = makeElement("button", "", "Try again");
      retry.type = "button";
      retry.addEventListener("click", fetchBadges);
      badgeState.append(retry);
      badgeState.hidden = false;
    }
  }

  refreshButton.addEventListener("click", fetchLeaderboard);
  fetchLeaderboard();
  fetchBadges();
  window.setInterval(fetchLeaderboard, REFRESH_INTERVAL);
})();