import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  type Client,
  type Message,
} from "discord.js";
import { randomUUID } from "node:crypto";
import { logger } from "./logger.js";
import { BotStore, type PollRecord, type ReminderRecord } from "./storage.js";
import { buildPollComponents, buildPollEmbed } from "./poll-ui.js";
import {
  handleModerationCommand,
  moderationSlashCommands,
} from "./moderation.js";
import { economySlashCommands, handleEconomyCommand } from "./economy.js";
import {
  handleSetupVerify,
  verificationSlashCommands,
} from "./verification.js";

const EPHEMERAL = 64;

const utilitySlashCommands = [
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check whether the bot is online."),
  new SlashCommandBuilder()
    .setName("poll")
    .setDescription("Post a poll with up to four choices.")
    .addStringOption((option) =>
      option
        .setName("question")
        .setDescription("What do you want to ask?")
        .setMaxLength(200)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("option1")
        .setDescription("First choice")
        .setMaxLength(60)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("option2")
        .setDescription("Second choice")
        .setMaxLength(60)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("option3")
        .setDescription("Optional third choice")
        .setMaxLength(60),
    )
    .addStringOption((option) =>
      option
        .setName("option4")
        .setDescription("Optional fourth choice")
        .setMaxLength(60),
    ),
  new SlashCommandBuilder()
    .setName("remind")
    .setDescription("Send yourself a reminder in this channel.")
    .addIntegerOption((option) =>
      option
        .setName("minutes")
        .setDescription("When to remind you (1 minute to 7 days)")
        .setMinValue(1)
        .setMaxValue(10_080)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("message")
        .setDescription("What should the reminder say?")
        .setMaxLength(1_000)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("role")
    .setDescription("Add or remove a self-assignable server role.")
    .addRoleOption((option) =>
      option
        .setName("role")
        .setDescription("The role to add or remove")
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("Show the bot's available commands."),
].map((command) => command.toJSON());

export const slashCommands = [
  ...utilitySlashCommands,
  ...moderationSlashCommands,
  ...economySlashCommands,
  ...verificationSlashCommands,
];

export async function handleCommand(
  interaction: ChatInputCommandInteraction,
  client: Client,
  store: BotStore,
): Promise<void> {
  try {
    switch (interaction.commandName) {
      case "ping":
        {
          const isMemberOfThisServer =
            interaction.guildId !== null &&
            client.guilds.cache.has(interaction.guildId);
          await interaction.reply({
            content:
              `Pong. Gateway latency: ${client.ws.ping} ms.\n` +
              `Bot account joined this server: ${isMemberOfThisServer ? "Yes" : "No"}.`,
            flags: EPHEMERAL,
          });
          return;
        }
      case "help":
        await interaction.reply({
          content:
            "**Available commands**\n" +
            "`/ping` — check the bot connection\n" +
            "`/poll` — create a poll with up to four choices\n" +
            "`/remind` — schedule a reminder in this channel\n" +
            "`/role` — toggle a self-assignable role\n" +
            "Rocket League: `/level`, `/leaderboard`, `/profile`, `/badges`, `/balance`, `/shop`, `/buy`, `/daily`, `/work`, `/crime`, `/vehicle`, `/nick`\n" +
            "Administrators: `/give-badge` — award a special badge to a member\n" +
            "Verification: `/setup-verify` — administrators can post a verification button\n" +
            "Moderators: `/ban`, `/kick`, `/timeout`, `/tempban`, `/unban`, `/case`",
          flags: EPHEMERAL,
        });
        return;
      case "setup-verify":
        await handleSetupVerify(interaction, store);
        return;
      case "poll":
        await createPoll(interaction, store);
        return;
      case "remind":
        await createReminder(interaction, store);
        return;
      case "role":
        await toggleRole(interaction);
        return;
      case "ban":
      case "kick":
      case "timeout":
      case "tempban":
      case "unban":
      case "case":
        await handleModerationCommand(interaction, store);
        return;
      case "level":
      case "leaderboard":
      case "profile":
      case "badges":
      case "give-badge":
      case "balance":
      case "shop":
      case "buy":
      case "nick":
      case "daily":
      case "work":
      case "crime":
      case "vehicle":
        await handleEconomyCommand(interaction, store);
        return;
      default:
        await interaction.reply({
          content: "I don't recognize that command.",
          flags: EPHEMERAL,
        });
    }
  } catch (error) {
    logger.error("Slash command failed", {
      command: interaction.commandName,
      error: errorMessage(error),
    });

    const response = {
      content: "That command could not be completed. Please try again.",
      flags: EPHEMERAL,
    } as const;

    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ content: response.content }).catch(() => {});
    } else {
      await interaction.reply(response).catch(() => {});
    }
  }
}

async function createPoll(
  interaction: ChatInputCommandInteraction,
  store: BotStore,
): Promise<void> {
  if (!interaction.inGuild() || !interaction.channel?.isSendable()) {
    await interaction.reply({
      content: "Polls can only be posted in a server channel.",
      flags: EPHEMERAL,
    });
    return;
  }

  const question = interaction.options.getString("question", true).trim();
  const options = [
    interaction.options.getString("option1", true).trim(),
    interaction.options.getString("option2", true).trim(),
    interaction.options.getString("option3")?.trim(),
    interaction.options.getString("option4")?.trim(),
  ].filter((value): value is string => Boolean(value));

  if (options.length < 2 || options.some((option) => !option)) {
    await interaction.reply({
      content: "Enter at least two non-empty choices.",
      flags: EPHEMERAL,
    });
    return;
  }

  await interaction.deferReply({ flags: EPHEMERAL });
  const id = randomUUID();
  const poll: PollRecord = {
    id,
    guildId: interaction.guildId,
    channelId: interaction.channelId,
    messageId: "",
    question,
    options,
    votes: {},
    createdAt: Date.now(),
  };

  let message: Message | undefined;
  try {
    message = await interaction.channel.send({
      embeds: [buildPollEmbed(poll)],
      components: [buildPollComponents(poll)],
    });
    poll.messageId = message.id;
    await store.addPoll(poll);
    await interaction.editReply({
      content: `Poll posted: https://discord.com/channels/${poll.guildId}/${poll.channelId}/${poll.messageId}`,
    });
  } catch (error) {
    if (message) {
      await message
        .edit({
          content: "This poll could not be saved. Please create it again.",
          embeds: [],
          components: [],
        })
        .catch(() => {});
    }
    throw error;
  }
}

async function createReminder(
  interaction: ChatInputCommandInteraction,
  store: BotStore,
): Promise<void> {
  if (!interaction.inGuild()) {
    await interaction.reply({
      content: "Reminders can only be scheduled in a server channel.",
      flags: EPHEMERAL,
    });
    return;
  }

  const minutes = interaction.options.getInteger("minutes", true);
  const text = interaction.options.getString("message", true).trim();
  if (!text) {
    await interaction.reply({
      content: "Enter a reminder message.",
      flags: EPHEMERAL,
    });
    return;
  }

  const reminder: ReminderRecord = {
    id: randomUUID(),
    guildId: interaction.guildId,
    channelId: interaction.channelId,
    userId: interaction.user.id,
    text,
    dueAt: Date.now() + minutes * 60_000,
  };
  await store.addReminder(reminder);
  await interaction.reply({
    content: `I’ll remind you here in ${minutes} minute${minutes === 1 ? "" : "s"}.`,
    flags: EPHEMERAL,
  });
}

async function toggleRole(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  if (!interaction.inCachedGuild()) {
    await interaction.reply({
      content: "This command needs to be used in a server.",
      flags: EPHEMERAL,
    });
    return;
  }

  const role = interaction.options.getRole("role", true);
  if (role.id === interaction.guildId || role.managed) {
    await interaction.reply({
      content: "That role cannot be self-assigned.",
      flags: EPHEMERAL,
    });
    return;
  }

  const botMember =
    interaction.guild.members.me ?? (await interaction.guild.members.fetchMe());
  if (role.comparePositionTo(botMember.roles.highest) >= 0) {
    await interaction.reply({
      content:
        "I can’t manage that role. Move my bot role above it in Server Settings → Roles.",
      flags: EPHEMERAL,
    });
    return;
  }

  const alreadyHasRole = interaction.member.roles.cache.has(role.id);
  if (alreadyHasRole) {
    await interaction.member.roles.remove(role, "Self-service role command");
    await interaction.reply({
      content: `Removed **${role.name}**.`,
      flags: EPHEMERAL,
    });
  } else {
    await interaction.member.roles.add(role, "Self-service role command");
    await interaction.reply({
      content: `Added **${role.name}**.`,
      flags: EPHEMERAL,
    });
  }
}

export async function deliverDueReminders(
  client: Client,
  store: BotStore,
): Promise<void> {
  const dueReminders = await store.getDueReminders();

  for (const reminder of dueReminders) {
    try {
      const channel = await client.channels.fetch(reminder.channelId);
      if (channel?.isSendable()) {
        await channel.send({
          content: `<@${reminder.userId}> — reminder: ${reminder.text}`,
          allowedMentions: { users: [reminder.userId] },
        });
        await store.removeReminder(reminder.id);
      } else {
        await store.rescheduleReminder(reminder.id, Date.now() + 5 * 60_000);
        logger.error("Reminder channel is unavailable; retrying in five minutes", {
          reminderId: reminder.id,
          channelId: reminder.channelId,
        });
      }
    } catch (error) {
      await store.rescheduleReminder(reminder.id, Date.now() + 5 * 60_000);
      logger.error("Reminder delivery failed; retrying in five minutes", {
        reminderId: reminder.id,
        error: errorMessage(error),
      });
    }
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}