import { randomInt } from "node:crypto";
import {
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
} from "discord.js";
import { BotStore } from "./storage.js";

const EPHEMERAL = 64;
const XP_PER_LEVEL = 100;
const NICKNAME_TROLL_DURATION_MS = 24 * 60 * 60_000;

interface ShopItem {
  id: string;
  name: string;
  cost: number;
  emoji: string;
  description: string;
  durationMs?: number;
  badgeId?: string;
}

interface BadgeDefinition {
  id: string;
  name: string;
  emoji: string;
  description: string;
  acquisition: string;
  cost?: number;
}

export const BADGE_CATALOG: readonly BadgeDefinition[] = [
  {
    id: "first-touch",
    name: "First Touch",
    emoji: "⚽",
    description: "A clean first touch starts every great play.",
    acquisition: "Purchase from /shop for 1,000 Credits.",
    cost: 1_000,
  },
  {
    id: "goal-getter",
    name: "Goal Getter",
    emoji: "👑",
    description: "For players who know how to finish the play.",
    acquisition: "Purchase from /shop for 4,000 Credits.",
    cost: 4_000,
  },
  {
    id: "aerial-master",
    name: "Aerial Master",
    emoji: "🚀",
    description: "A badge for taking your game above the field.",
    acquisition: "Purchase from /shop for 10,000 Credits.",
    cost: 10_000,
  },
  {
    id: "tournament-winner",
    name: "Tournament Winner",
    emoji: "🏆",
    description: "Awarded by an administrator for tournament success.",
    acquisition: "Awarded by a server administrator for tournament success.",
  },
  {
    id: "server-veteran",
    name: "Server Veteran",
    emoji: "🛡️",
    description: "A special badge awarded by a server administrator.",
    acquisition: "Awarded by a server administrator.",
  },
];

const SHOP_BADGES = BADGE_CATALOG.filter(
  (badge): badge is BadgeDefinition & { cost: number } =>
    badge.cost !== undefined,
);
const STAFF_BADGES = BADGE_CATALOG.filter(
  (badge) => badge.cost === undefined,
);

const SHOP_ITEMS: readonly ShopItem[] = [
  {
    id: "custom-roll-color",
    name: "Custom Roll Color",
    cost: 2_500,
    emoji: "🎨",
    description:
      "Request a unique color for your name in this server. Ask a moderator for help after purchase.",
  },
  {
    id: "fennec-body",
    name: "Fennec Body",
    cost: 5_000,
    emoji: "🚙",
    description: "A cosmetic collectible saved to your /profile inventory.",
  },
  {
    id: "titanium-white-octane",
    name: "Titanium White Octane",
    cost: 15_000,
    emoji: "🏆",
    description: "The ultimate status item to show off in your /profile.",
  },
  {
    id: "nickname-troll",
    name: "Nickname Troll",
    cost: 3_500,
    emoji: "📛",
    durationMs: NICKNAME_TROLL_DURATION_MS,
    description:
      "A 24-hour pass to change another member's server nickname with /nick.",
  },
  ...SHOP_BADGES.map((badge) => ({
    id: `badge-${badge.id}`,
    badgeId: badge.id,
    name: badge.name,
    cost: badge.cost,
    emoji: badge.emoji,
    description: badge.description,
  })),
];

const workStories = [
  "You coached a Hardstuck Gold player through better rotations.",
  "You won a local 3v3 tournament.",
  "You ran a kickoff clinic for a team headed to the finals.",
  "You helped a teammate land a clean flip reset.",
  "You reviewed replays and spotted a game-winning back-post rotation.",
];

const crimeSuccessStories = [
  "You demo-smuggled into the opponent's end zone.",
  "You stole the opponent's 100 boost and escaped cleanly.",
  "You sneaked a fake kickoff past the other team's defense.",
  "You slipped a suspiciously perfect redirect into the net.",
];

const crimeFailureStories = [
  "You got caught trying to steal the opponent's 100 boost.",
  "Your demo-smuggling attempt ended in a very public whiff.",
  "The other team spotted your fake kickoff from midfield.",
  "You got demoed while trying to make your getaway.",
];

export const economySlashCommands = [
  new SlashCommandBuilder()
    .setName("level")
    .setDescription("Check a player's XP, level, and Rocket League rank.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Player to check (defaults to you)"),
    ),
  new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("See the server's top players and richest members."),
  new SlashCommandBuilder()
    .setName("profile")
    .setDescription("View a player's Rocket League profile.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Player to view (defaults to you)"),
    ),
  new SlashCommandBuilder()
    .setName("badges")
    .setDescription("View the badges collected by you or another player.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Player to view (defaults to you)"),
    ),
  new SlashCommandBuilder()
    .setName("give-badge")
    .setDescription("Give a special badge to a server member.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Member who should receive the badge")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("badge_name")
        .setDescription("Special badge to award")
        .setRequired(true)
        .addChoices(
          ...STAFF_BADGES.map((badge) => ({
            name: `${badge.emoji} ${badge.name}`,
            value: badge.id,
          })),
        ),
    ),
  new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your Credits or another member's balance.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Member to check (defaults to you)"),
    ),
  new SlashCommandBuilder()
    .setName("shop")
    .setDescription("Browse Rocket League items available for Credits."),
  new SlashCommandBuilder()
    .setName("buy")
    .setDescription("Buy a Rocket League item with your Credits.")
    .addStringOption((option) =>
      option
        .setName("item")
        .setDescription("Item to purchase")
        .setRequired(true)
        .addChoices(
          ...SHOP_ITEMS.map((item) => ({
            name: `${item.emoji} ${item.name} — ${item.cost.toLocaleString()} Credits`,
            value: item.id,
          })),
        ),
    ),
  new SlashCommandBuilder()
    .setName("nick")
    .setDescription("Use an active Nickname Troll pass to rename a member.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Member whose nickname you want to change")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("nickname")
        .setDescription("Their new server nickname")
        .setMinLength(1)
        .setMaxLength(32)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("daily")
    .setDescription("Claim your daily 500 Credits."),
  new SlashCommandBuilder()
    .setName("work")
    .setDescription("Take a Rocket League job to earn Credits."),
  new SlashCommandBuilder()
    .setName("crime")
    .setDescription("Try a risky Rocket League hustle for Credits."),
  new SlashCommandBuilder()
    .setName("vehicle")
    .setDescription("Set or clear your favorite Rocket League vehicle.")
    .addStringOption((option) =>
      option
        .setName("favorite_vehicle")
        .setDescription("Your favorite vehicle")
        .setRequired(true)
        .addChoices(
          { name: "Octane", value: "Octane" },
          { name: "Fennec", value: "Fennec" },
          { name: "Dominus", value: "Dominus" },
          { name: "Other", value: "Other" },
          { name: "Clear favorite", value: "none" },
        ),
    ),
].map((command) => command.toJSON());

export async function handleEconomyCommand(
  interaction: ChatInputCommandInteraction,
  store: BotStore,
): Promise<void> {
  if (!interaction.inCachedGuild()) {
    await interaction.reply({
      content: "Rocket League stats and Credits are available in a server.",
      flags: EPHEMERAL,
    });
    return;
  }

  switch (interaction.commandName) {
    case "level":
      await showLevel(interaction, store);
      return;
    case "leaderboard":
      await showLeaderboard(interaction, store);
      return;
    case "profile":
      await showProfile(interaction, store);
      return;
    case "badges":
      await showBadges(interaction, store);
      return;
    case "give-badge":
      await giveBadge(interaction, store);
      return;
    case "balance":
      await showBalance(interaction, store);
      return;
    case "shop":
      await showShop(interaction);
      return;
    case "buy":
      await buyShopItem(interaction, store);
      return;
    case "nick":
      await useNicknameTroll(interaction, store);
      return;
    case "daily":
      await claimDaily(interaction, store);
      return;
    case "work":
      await workForCredits(interaction, store);
      return;
    case "crime":
      await commitCrime(interaction, store);
      return;
    case "vehicle":
      await setVehicle(interaction, store);
  }
}

export function getPublicBadgeCatalog(): Array<{
  id: string;
  name: string;
  emoji: string;
  description: string;
  cost: number | null;
  acquisition: string;
}> {
  return BADGE_CATALOG.map((badge) => ({
    id: badge.id,
    name: badge.name,
    emoji: badge.emoji,
    description: badge.description,
    cost: badge.cost ?? null,
    acquisition: badge.acquisition,
  }));
}

async function showLevel(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const user = interaction.options.getUser("user") ?? interaction.user;
  const profile = await store.getEconomyProfile(interaction.guildId, user.id);
  const currentLevelXp = profile.xp % XP_PER_LEVEL;
  const nextLevelXp = XP_PER_LEVEL - currentLevelXp;

  await interaction.reply({
    content:
      `**${user.username}** — Level **${profile.level}** · **${rankForLevel(profile.level)}**\n` +
      `XP: **${profile.xp} total** · ${currentLevelXp}/${XP_PER_LEVEL} toward the next level (${nextLevelXp} to go).`,
    allowedMentions: { parse: [] },
  });
}

async function showLeaderboard(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const profiles = (await store.getEconomyLeaderboard(interaction.guildId))
    .filter((profile) => profile.xp > 0 || profile.credits > 0)
    .sort((a, b) => b.xp - a.xp);
  if (profiles.length === 0) {
    await interaction.reply({
      content: "No server stats yet. Chat to earn XP or claim `/daily` Credits.",
    });
    return;
  }

  const byCredits = [...profiles].sort(
    (a, b) => b.credits - a.credits || b.xp - a.xp,
  );
  const levelLines = profiles
    .slice(0, 10)
    .map(
      (profile, index) =>
        `**${index + 1}.** <@${profile.userId}> — Level ${profile.level} · ${profile.xp} XP`,
    );
  const creditLines = byCredits
    .slice(0, 10)
    .map(
      (profile, index) =>
        `**${index + 1}.** <@${profile.userId}> — ${profile.credits} Credits`,
    );

  const embed = new EmbedBuilder()
    .setColor(0x1f9d63)
    .setTitle("Rocket League Server Leaderboard")
    .setDescription("Climb the ranks, stack Credits, and own the pitch.")
    .addFields(
      { name: "Top Players · Level / XP", value: levelLines.join("\n") },
      { name: "Most Credits", value: creditLines.join("\n") },
    );

  await interaction.reply({
    embeds: [embed],
    allowedMentions: { parse: [] },
  });
}

async function showProfile(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const user = interaction.options.getUser("user") ?? interaction.user;
  const profile = await store.getEconomyProfile(interaction.guildId, user.id);
  const progress = profile.xp % XP_PER_LEVEL;
  const embed = new EmbedBuilder()
    .setColor(0x1677d2)
    .setTitle(`${user.username}'s Rocket League Profile`.slice(0, 256))
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields(
      {
        name: "Rank",
        value: `Level ${profile.level} · ${rankForLevel(profile.level)}`,
        inline: true,
      },
      {
        name: "XP",
        value: `${profile.xp} total · ${progress}/${XP_PER_LEVEL} to next level`,
        inline: true,
      },
      {
        name: "Credits",
        value: `${profile.credits.toLocaleString()} Credits`,
        inline: true,
      },
      {
        name: "Inventory",
        value: formatInventory(profile.inventory),
      },
    );

  if (profile.favoriteVehicle) {
    embed.addFields({
      name: "Favorite Vehicle",
      value: profile.favoriteVehicle,
      inline: true,
    });
  }

  await interaction.reply({ embeds: [embed] });
}

async function showBadges(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const user = interaction.options.getUser("user") ?? interaction.user;
  const profile = await store.getEconomyProfile(interaction.guildId, user.id);
  const badgeLines = profile.badges.map((badgeId) => {
    const badge = BADGE_DEFINITIONS.find((entry) => entry.id === badgeId);
    return badge
      ? `${badge.emoji} **${badge.name}**\n${badge.description}`
      : `🏅 **${badgeId}**`;
  });
  const embed = new EmbedBuilder()
    .setColor(0xf2c94c)
    .setTitle(`🏅 ${user.username}'s Badges`)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .setDescription(
      badgeLines.length > 0
        ? badgeLines.join("\n\n")
        : "No badges collected yet. Visit `/shop` to buy one or earn a special badge from an administrator.",
    )
    .setFooter({
      text: `${profile.badges.length} badge${profile.badges.length === 1 ? "" : "s"} collected`,
    });

  await interaction.reply({ embeds: [embed] });
}

async function giveBadge(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  if (
    !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)
  ) {
    await interaction.reply({
      content: "Only server administrators can give special badges.",
      flags: EPHEMERAL,
    });
    return;
  }

  const user = interaction.options.getUser("user", true);
  const badgeId = interaction.options.getString("badge_name", true);
  const badge = STAFF_BADGES.find((entry) => entry.id === badgeId);
  if (!badge) {
    await interaction.reply({
      content: "That special badge is not available to give.",
      flags: EPHEMERAL,
    });
    return;
  }

  const result = await store.grantBadge(interaction.guildId, user.id, badge.id);
  await interaction.reply({
    content:
      result.status === "already_owned"
        ? `${user.username} already has ${badge.emoji} **${badge.name}**.`
        : `Granted ${badge.emoji} **${badge.name}** to **${user.username}**.`,
    flags: EPHEMERAL,
  });
}

async function showBalance(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const user = interaction.options.getUser("user") ?? interaction.user;
  const profile = await store.getEconomyProfile(interaction.guildId, user.id);
  const embed = new EmbedBuilder()
    .setColor(0xf2c94c)
    .setTitle("💳 Credit Wallet")
    .setDescription(`**${user.username}**'s Rocket League account`)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields({
      name: "Available balance",
      value: `🪙 **${profile.credits.toLocaleString()} Credits**`,
    })
    .setFooter({ text: "Rocket League Economy" });

  await interaction.reply({ embeds: [embed] });
}

async function showShop(
  interaction: ChatInputCommandInteraction<"cached">,
): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("🏁 Rocket League Item Shop")
    .setDescription(
      "Spend Credits on collectibles, passes, and badges. Use `/buy` to purchase; badges appear in `/badges`.",
    )
    .addFields(
      ...SHOP_ITEMS.map((item) => ({
        name: `${item.emoji} ${item.name} · 🪙 ${item.cost.toLocaleString()} Credits`,
        value: item.description,
      })),
    )
    .setFooter({ text: "Prices are paid once when you buy an item." });

  await interaction.reply({ embeds: [embed] });
}

async function buyShopItem(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const itemId = interaction.options.getString("item", true);
  const item = SHOP_ITEMS.find((entry) => entry.id === itemId);
  if (!item) {
    await interaction.reply({
      content: "That item is not available in the shop.",
      flags: EPHEMERAL,
    });
    return;
  }

  if (item.badgeId) {
    const badge = BADGE_DEFINITIONS.find(
      (entry) => entry.id === item.badgeId,
    );
    if (!badge) {
      throw new Error(`Shop badge ${item.badgeId} is missing from the catalog.`);
    }

    const result = await store.purchaseBadge(
      interaction.guildId,
      interaction.user.id,
      badge.id,
      item.cost,
    );
    if (result.status === "already_owned") {
      await interaction.reply({
        content: `You already own ${badge.emoji} **${badge.name}**. Check \`/badges\`.`,
        flags: EPHEMERAL,
      });
      return;
    }
    if (result.status === "insufficient_credits") {
      await interaction.reply({
        content:
          `You need **${item.cost.toLocaleString()} Credits** for ${badge.emoji} **${badge.name}**, ` +
          `but your balance is **${result.profile.credits.toLocaleString()} Credits**.`,
        flags: EPHEMERAL,
      });
      return;
    }

    await interaction.reply({
      content:
        `Purchased ${badge.emoji} **${badge.name}** for **${item.cost.toLocaleString()} Credits**. ` +
        `It is now in your \`/badges\` collection. Remaining balance: **${result.profile.credits.toLocaleString()} Credits**.`,
      flags: EPHEMERAL,
    });
    return;
  }

  const result = await store.purchaseShopItem(
    interaction.guildId,
    interaction.user.id,
    item.id,
    item.cost,
    item.durationMs,
  );

  if (result.status === "already_owned") {
    await interaction.reply({
      content: `You already own **${item.name}**. Check your \`/profile\` inventory.`,
      flags: EPHEMERAL,
    });
    return;
  }
  if (result.status === "insufficient_credits") {
    await interaction.reply({
      content:
        `You need **${item.cost.toLocaleString()} Credits** for **${item.name}**, ` +
        `but your balance is **${result.profile.credits.toLocaleString()} Credits**.`,
      flags: EPHEMERAL,
    });
    return;
  }

  const purchasedItem = result.profile.inventory.find(
    (entry) => entry.itemId === item.id,
  );
  const passExpiry =
    purchasedItem?.expiresAt === undefined
      ? ""
      : ` Your pass is active until <t:${Math.floor(purchasedItem.expiresAt / 1000)}:R>.`;
  const moderatorNote =
    item.id === "custom-roll-color"
      ? " Ask a moderator to set up your unique name color."
      : "";
  await interaction.reply({
    content:
      `Purchased **${item.name}** for **${item.cost.toLocaleString()} Credits**.` +
      ` Remaining balance: **${result.profile.credits.toLocaleString()} Credits**.` +
      passExpiry +
      moderatorNote,
    flags: EPHEMERAL,
  });
}

async function useNicknameTroll(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const targetUser = interaction.options.getUser("user", true);
  const nickname = interaction.options.getString("nickname", true).trim();
  if (!nickname) {
    await interaction.reply({
      content: "Enter a nickname with at least one non-space character.",
      flags: EPHEMERAL,
    });
    return;
  }
  if (targetUser.id === interaction.user.id || targetUser.bot) {
    await interaction.reply({
      content: "Choose another human member of this server.",
      flags: EPHEMERAL,
    });
    return;
  }

  const now = Date.now();
  const profile = await store.getEconomyProfile(
    interaction.guildId,
    interaction.user.id,
  );
  const pass = profile.inventory.find(
    (item) =>
      item.itemId === "nickname-troll" &&
      item.expiresAt !== undefined &&
      item.expiresAt > now,
  );
  if (!pass?.expiresAt) {
    await interaction.reply({
      content:
        "You need an active **Nickname Troll** pass to use `/nick`. Buy one in `/shop`.",
      flags: EPHEMERAL,
    });
    return;
  }

  const botMember =
    interaction.guild.members.me ?? (await interaction.guild.members.fetchMe());
  if (!botMember.permissions.has(PermissionFlagsBits.ManageNicknames)) {
    await interaction.reply({
      content:
        "I need the **Manage Nicknames** permission before I can apply that nickname.",
      flags: EPHEMERAL,
    });
    return;
  }

  let targetMember;
  try {
    targetMember = await interaction.guild.members.fetch(targetUser.id);
  } catch {
    await interaction.reply({
      content: "That user is not a member of this server.",
      flags: EPHEMERAL,
    });
    return;
  }

  if (!targetMember.manageable) {
    await interaction.reply({
      content:
        "I can't change that member's nickname. Their role may be above mine, or they may own the server.",
      flags: EPHEMERAL,
    });
    return;
  }

  await targetMember.setNickname(
    nickname,
    `Nickname Troll pass used by ${interaction.user.username}`,
  );
  await interaction.reply({
    content:
      `Changed <@${targetMember.id}>'s server nickname to **${nickname}**. ` +
      `Your pass remains active until <t:${Math.floor(pass.expiresAt / 1000)}:R>.`,
    allowedMentions: { parse: [] },
    flags: EPHEMERAL,
  });
}

async function claimDaily(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const result = await store.performEconomyAction(
    interaction.guildId,
    interaction.user.id,
    "daily",
    500,
  );
  if (!result.accepted) {
    await interaction.reply({
      content: `You already claimed your daily Credits. Try again in **${formatCooldown(result.remainingMs)}**.`,
      flags: EPHEMERAL,
    });
    return;
  }

  await interaction.reply({
    content: `Daily drop claimed: **500 Credits**. Your balance is **${result.profile.credits.toLocaleString()} Credits**.`,
    flags: EPHEMERAL,
  });
}

async function workForCredits(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const reward = randomInt(100, 501);
  const story = randomChoice(workStories);
  const result = await store.performEconomyAction(
    interaction.guildId,
    interaction.user.id,
    "work",
    reward,
  );
  if (!result.accepted) {
    await interaction.reply({
      content: `You're still on cooldown. Your next job opens in **${formatCooldown(result.remainingMs)}**.`,
      flags: EPHEMERAL,
    });
    return;
  }

  await interaction.reply({
    content: `${story} You earned **${result.creditsChange} Credits**. Balance: **${result.profile.credits.toLocaleString()} Credits**.`,
    flags: EPHEMERAL,
  });
}

async function commitCrime(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const succeeded = randomInt(0, 2) === 1;
  const requestedChange = succeeded
    ? randomInt(200, 701)
    : -randomInt(150, 401);
  const result = await store.performEconomyAction(
    interaction.guildId,
    interaction.user.id,
    "crime",
    requestedChange,
  );
  if (!result.accepted) {
    await interaction.reply({
      content: `Your next risky play opens in **${formatCooldown(result.remainingMs)}**.`,
      flags: EPHEMERAL,
    });
    return;
  }

  if (succeeded) {
    await interaction.reply({
      content: `${randomChoice(crimeSuccessStories)} You got away with **${result.creditsChange} Credits**. Balance: **${result.profile.credits.toLocaleString()} Credits**.`,
      flags: EPHEMERAL,
    });
    return;
  }

  const actualLoss = Math.abs(result.creditsChange);
  const lossMessage =
    actualLoss > 0
      ? `You lost **${actualLoss} Credits**.`
      : "You had no Credits to lose.";
  await interaction.reply({
    content: `${randomChoice(crimeFailureStories)} ${lossMessage} Balance: **${result.profile.credits.toLocaleString()} Credits**.`,
    flags: EPHEMERAL,
  });
}

async function setVehicle(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const choice = interaction.options.getString("favorite_vehicle", true);
  const vehicle = choice === "none" ? null : choice;
  await store.setFavoriteVehicle(
    interaction.guildId,
    interaction.user.id,
    vehicle,
  );

  await interaction.reply({
    content: vehicle
      ? `Favorite vehicle set to **${vehicle}**.`
      : "Your favorite vehicle was cleared.",
    flags: EPHEMERAL,
  });
}

function rankForLevel(level: number): string {
  if (level <= 5) return "Bronze";
  if (level <= 10) return "Silver";
  if (level <= 15) return "Gold";
  if (level <= 20) return "Platinum";
  if (level <= 25) return "Diamond";
  if (level <= 30) return "Champion";
  return "Grand Champion";
}

function formatCooldown(remainingMs: number): string {
  const totalMinutes = Math.max(1, Math.ceil(remainingMs / 60_000));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) {
    return `${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
  }
  return `${hours} hour${hours === 1 ? "" : "s"}${
    minutes > 0 ? ` ${minutes} minute${minutes === 1 ? "" : "s"}` : ""
  }`;
}

function randomChoice(items: string[]): string {
  return items[randomInt(items.length)]!;
}

function formatInventory(
  inventory: Array<{ itemId: string; expiresAt?: number }>,
): string {
  if (inventory.length === 0) return "No items yet. Visit `/shop` to browse.";
  const now = Date.now();
  return inventory
    .map((entry) => {
      const item = SHOP_ITEMS.find((shopItem) => shopItem.id === entry.itemId);
      const label = `${item?.emoji ?? "🎁"} **${item?.name ?? entry.itemId}**`;
      if (entry.expiresAt === undefined) return label;
      return entry.expiresAt > now
        ? `${label} — active until <t:${Math.floor(entry.expiresAt / 1000)}:R>`
        : `${label} — expired`;
    })
    .join("\n");
}