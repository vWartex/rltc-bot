import {
  Client,
  ActivityType,
  Events,
  GatewayIntentBits,
  MessageFlags,
  type ButtonInteraction,
} from "discord.js";
import express from "express";
import { randomInt } from "node:crypto";
import { handleCommand, deliverDueReminders, slashCommands } from "./commands.js";
import { logger } from "./logger.js";
import { handleCasePageButton, processDueTempBans } from "./moderation.js";
import { buildPollComponents, buildPollEmbed } from "./poll-ui.js";
import { BotStore } from "./storage.js";
import { handleVerificationButton } from "./verification.js";

const token = process.env.DISCORD_TOKEN;
if (!token) {
  throw new Error("DISCORD_TOKEN is missing. Add it in Replit Secrets.");
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
});
const store = new BotStore();
let schedulerTimer: NodeJS.Timeout | undefined;
let deliveringReminders = false;
let processingTempBans = false;
let storeReady = false;

const healthApp = express();
healthApp.get("/", (_request, response) => {
  response.type("text/plain").send("The bot is alive!");
});

const healthPort = Number(process.env.PORT || 3000);
if (!Number.isInteger(healthPort) || healthPort < 1 || healthPort > 65535) {
  throw new Error(`Invalid health server port: ${process.env.PORT}`);
}

const healthServer = healthApp.listen(healthPort, "0.0.0.0", () => {
  logger.info("Health server is listening", { port: healthPort });
});
healthServer.on("error", (error: Error) => {
  logger.error("Health server failed to start", {
    error: errorMessage(error),
    port: healthPort,
  });
  if (schedulerTimer) clearInterval(schedulerTimer);
  process.exitCode = 1;
  client.destroy();
});

client.once(Events.ClientReady, (readyClient) => {
  void startBot(readyClient).catch((error: unknown) => {
    logger.error("Bot startup failed", { error: errorMessage(error) });
    process.exitCode = 1;
    closeHealthServer();
    client.destroy();
  });
});

client.on(Events.InteractionCreate, (interaction) => {
  if (interaction.isChatInputCommand()) {
    void handleCommand(interaction, client, store);
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith("poll:")) {
    void handlePollVote(interaction);
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith("casepage:")) {
    void handleCasePageButton(interaction, store);
    return;
  }

  if (interaction.isButton() && interaction.customId === "verify:member") {
    void handleVerificationButton(interaction, store);
  }
});

client.on(Events.MessageCreate, (message) => {
  if (
    !storeReady ||
    !message.guildId ||
    message.author.bot ||
    message.webhookId
  ) {
    return;
  }

  const xpAmount = randomInt(15, 26);
  void store
    .awardMessageXp(message.guildId, message.author.id, xpAmount)
    .catch((error: unknown) => {
      logger.error("Could not award message XP", {
        guildId: message.guildId,
        userId: message.author.id,
        error: errorMessage(error),
      });
    });
});

client.on(Events.Error, (error) => {
  logger.error("Discord client error", { error: error.message });
});

client.on(Events.ShardDisconnect, (closeEvent, shardId) => {
  logger.error("Discord gateway shard disconnected without automatic recovery", {
    shardId,
    closeCode: closeEvent.code,
    closeReason: String(closeEvent.reason),
    wasClean: closeEvent.wasClean,
  });
});

client.on(Events.ShardError, (error, shardId) => {
  logger.error("Discord gateway shard error", {
    shardId,
    error: errorMessage(error),
  });
});

client.on(Events.ShardReconnecting, (shardId) => {
  logger.info("Discord gateway shard reconnecting", { shardId });
});

client.on(Events.ShardReady, (shardId, unavailableGuilds) => {
  logger.info("Discord gateway shard ready", {
    shardId,
    unavailableGuildCount: unavailableGuilds?.size ?? 0,
  });
  setOnlinePresence();
});

client.on(Events.ShardResume, (shardId, replayedEvents) => {
  logger.info("Discord gateway shard resumed", { shardId, replayedEvents });
  setOnlinePresence();
});

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.once(signal, () => {
    if (schedulerTimer) clearInterval(schedulerTimer);
    logger.info("Shutting down Discord bot", { signal });
    closeHealthServer();
    client.destroy();
  });
}

async function startBot(
  readyClient: Client<true>,
): Promise<void> {
  await store.initialize();
  storeReady = true;
  readyClient.user.setPresence({
    status: "online",
    activities: [{ name: "/help", type: ActivityType.Listening }],
  });
  await readyClient.application.commands.set(slashCommands);
  logger.info("Discord bot is ready", {
    username: readyClient.user.tag,
    commandCount: slashCommands.length,
    presence: "online",
    guildCount: readyClient.guilds.cache.size,
  });

  await Promise.all([deliverRemindersSafely(), processTempBansSafely()]);
  schedulerTimer = setInterval(() => {
    void deliverRemindersSafely();
    void processTempBansSafely();
  }, 15_000);
}

async function deliverRemindersSafely(): Promise<void> {
  if (deliveringReminders) return;
  deliveringReminders = true;
  try {
    await deliverDueReminders(client, store);
  } catch (error) {
    logger.error("Could not check due reminders", {
      error: errorMessage(error),
    });
  } finally {
    deliveringReminders = false;
  }
}

async function processTempBansSafely(): Promise<void> {
  if (processingTempBans) return;
  processingTempBans = true;
  try {
    await processDueTempBans(client, store);
  } catch (error) {
    logger.error("Could not check expired temporary bans", {
      error: errorMessage(error),
    });
  } finally {
    processingTempBans = false;
  }
}

async function handlePollVote(interaction: ButtonInteraction): Promise<void> {
  try {
    const [, pollId, rawOption] = interaction.customId.split(":");
    const optionIndex = Number(rawOption);
    if (!pollId || !Number.isInteger(optionIndex)) {
      await interaction.reply({
        content: "This poll button is invalid.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const poll = await store.castVote(pollId, interaction.user.id, optionIndex);
    if (!poll || poll.guildId !== interaction.guildId) {
      await interaction.reply({
        content: "This poll is no longer available.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.update({
      embeds: [buildPollEmbed(poll)],
      components: [buildPollComponents(poll)],
    });
  } catch (error) {
    logger.error("Poll vote failed", { error: errorMessage(error) });
    const content = "Your vote could not be saved. Please try again.";
    if (interaction.deferred || interaction.replied) {
      await interaction
        .followUp({ content, flags: MessageFlags.Ephemeral })
        .catch(() => {});
    } else {
      await interaction.reply({ content, flags: MessageFlags.Ephemeral }).catch(() => {});
    }
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function setOnlinePresence(): void {
  client.user?.setPresence({
    status: "online",
    activities: [{ name: "/help", type: ActivityType.Listening }],
  });
}

function closeHealthServer(): void {
  if (healthServer.listening) {
    healthServer.close();
  }
}

client.login(token).catch((error: unknown) => {
  logger.error("Could not connect to Discord", { error: errorMessage(error) });
  process.exitCode = 1;
  closeHealthServer();
});