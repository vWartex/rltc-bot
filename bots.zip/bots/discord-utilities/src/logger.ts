type LogFields = Record<string, string | number | boolean | null | undefined>;

function write(
  level: "info" | "error",
  message: string,
  fields?: LogFields,
): void {
  const line = JSON.stringify({
    time: new Date().toISOString(),
    level,
    message,
    ...fields,
  });

  if (level === "error") {
    process.stderr.write(`${line}\n`);
  } else {
    process.stdout.write(`${line}\n`);
  }
}

export const logger = {
  info: (message: string, fields?: LogFields) => write("info", message, fields),
  error: (message: string, fields?: LogFields) => write("error", message, fields),
};