import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  type ButtonInteraction,
  type BaseInteraction,
  type ChatInputCommandInteraction,
  type Client,
  type GuildMember,
} from "discord.js";
import { logger } from "./logger.js";
import {
  BotStore,
  type ModerationAction,
  type ModerationCase,
  type NewModerationCase,
  type TempBanJob,
} from "./storage.js";

const EPHEMERAL = 64;
const MAX_TIMEOUT_MINUTES = 40_320;
const CASES_PER_PAGE = 5;
const TEMP_BAN_RETRY_MS = 5 * 60_000;

export const moderationSlashCommands = [
  new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Permanently ban a user.")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((option) =>
      option.setName("user").setDescription("User to ban").setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason for the ban")
        .setMaxLength(400)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member from the server.")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to kick").setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason for the kick")
        .setMaxLength(400)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Time out a member for a number of minutes.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("Member to time out")
        .setRequired(true),
    )
    .addIntegerOption((option) =>
      option
        .setName("time_in_minutes")
        .setDescription("Timeout duration (1 to 40,320 minutes)")
        .setMinValue(1)
        .setMaxValue(MAX_TIMEOUT_MINUTES)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason for the timeout")
        .setMaxLength(400)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("tempban")
    .setDescription("Ban a user and automatically unban them later.")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((option) =>
      option.setName("user").setDescription("User to ban").setRequired(true),
    )
    .addIntegerOption((option) =>
      option
        .setName("time_in_hours")
        .setDescription("How many hours the ban should last")
        .setMinValue(1)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason for the temporary ban")
        .setMaxLength(400)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Unban a user by their Discord ID.")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((option) =>
      option
        .setName("user_id")
        .setDescription("Discord ID of the user to unban")
        .setMinLength(17)
        .setMaxLength(20)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("case")
    .setDescription("View a user's moderation history.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("User whose cases you want to view")
        .setRequired(true),
    ),
].map((command) => command.toJSON());

const requiredPermission: Partial<Record<string, bigint>> = {
  ban: PermissionFlagsBits.BanMembers,
  kick: PermissionFlagsBits.KickMembers,
  timeout: PermissionFlagsBits.ModerateMembers,
  tempban: PermissionFlagsBits.BanMembers,
  unban: PermissionFlagsBits.BanMembers,
};

export async function handleModerationCommand(
  interaction: ChatInputCommandInteraction,
  store: BotStore,
): Promise<void> {
  const commandName = interaction.commandName;
  if (commandName === "case") {
    // Discord's default permission bitset cannot express this OR policy;
    // enforce each accepted moderator permission explicitly at runtime.
    if (!canViewCases(interaction)) {
      await replyEphemeral(
        interaction,
        "You need Administrator, Moderate Members, Ban Members, or Kick Members permission to view cases.",
      );
      return;
    }
  } else {
    const permission = requiredPermission[commandName];
    if (!permission || !hasPermission(interaction, permission)) {
      await replyEphemeral(
        interaction,
        "You don't have permission to use this moderation command.",
      );
      return;
    }
  }

  if (!interaction.inCachedGuild()) {
    await replyEphemeral(
      interaction,
      "The bot must be installed to this server with the Guild Install option before moderation commands can run.",
    );
    return;
  }

  switch (commandName) {
    case "ban":
      await banUser(interaction, store, false);
      return;
    case "kick":
      await kickMember(interaction, store);
      return;
    case "timeout":
      await timeoutMember(interaction, store);
      return;
    case "tempban":
      await banUser(interaction, store, true);
      return;
    case "unban":
      await unbanUser(interaction, store);
      return;
    case "case":
      await showCases(interaction, store);
  }
}

export async function handleCasePageButton(
  interaction: ButtonInteraction,
  store: BotStore,
): Promise<void> {
  try {
    const match = /^casepage:(\d{17,20}):(\d{17,20}):(\d+)$/.exec(
      interaction.customId,
    );
    if (!match) {
      await interaction.reply({
        content: "This case-history button is invalid.",
        flags: EPHEMERAL,
      });
      return;
    }

    const [, requesterId, targetId, rawPage] = match;
    if (interaction.user.id !== requesterId) {
      await interaction.reply({
        content: "Only the moderator who opened this history can change pages.",
        flags: EPHEMERAL,
      });
      return;
    }
    if (!interaction.inCachedGuild() || !canViewCases(interaction)) {
      await interaction.reply({
        content: "You no longer have permission to view moderation cases.",
        flags: EPHEMERAL,
      });
      return;
    }

    const cases = await store.getModerationCases(
      interaction.guildId,
      targetId,
    );
    const page = Number(rawPage);
    if (cases.length === 0) {
      await interaction.update({
        content: "No moderation cases were found for that user.",
        embeds: [],
        components: [],
      });
      return;
    }

    await interaction.update(buildCaseHistory(targetId, cases, page, requesterId));
  } catch (error) {
    logger.error("Could not change moderation case page", {
      error: errorMessage(error),
    });
    const content = "Could not load this page. Please run `/case` again.";
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({ content, flags: EPHEMERAL }).catch(() => {});
    } else {
      await interaction.reply({ content, flags: EPHEMERAL }).catch(() => {});
    }
  }
}

export async function processDueTempBans(
  client: Client,
  store: BotStore,
): Promise<void> {
  const dueJobs = await store.getDueTempBans();

  for (const job of dueJobs) {
    const guild = client.guilds.cache.get(job.guildId);
    if (!guild) {
      await store.rescheduleTempBan(
        job.caseNumber,
        Date.now() + TEMP_BAN_RETRY_MS,
      );
      logger.error("Cannot expire temporary ban while bot is outside the server", {
        caseNumber: job.caseNumber,
        guildId: job.guildId,
      });
      continue;
    }

    try {
      await guild.members.unban(
        job.userId,
        `Temporary ban expired (Case #${job.caseNumber})`,
      );
      await store.finishTempBan(job.caseNumber, automaticUnbanCase(client, job));
      logger.info("Temporary ban expired", {
        caseNumber: job.caseNumber,
        guildId: job.guildId,
      });
    } catch (error) {
      if (discordErrorCode(error) === 10026) {
        try {
          await store.finishTempBan(
            job.caseNumber,
            automaticUnbanCase(client, job, true),
          );
          logger.info("Temporary ban had already been removed", {
            caseNumber: job.caseNumber,
            guildId: job.guildId,
          });
          continue;
        } catch (storageError) {
          error = storageError;
        }
      }

      await store.rescheduleTempBan(
        job.caseNumber,
        Date.now() + TEMP_BAN_RETRY_MS,
      );
      logger.error("Temporary unban failed; retrying in five minutes", {
        caseNumber: job.caseNumber,
        guildId: job.guildId,
        error: errorMessage(error),
      });
    }
  }
}

async function banUser(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
  temporary: boolean,
): Promise<void> {
  const target = interaction.options.getUser("user", true);
  const reason = interaction.options.getString("reason", true).trim();
  if (!(await validateTarget(interaction, target.id, target.tag))) return;
  if (!(await validateReason(interaction, reason))) return;

  const targetMember = await fetchMemberIfPresent(interaction, target.id);
  if (
    targetMember &&
    !(await validateMemberHierarchy(interaction, targetMember, "ban"))
  ) {
    return;
  }

  const hours = temporary
    ? interaction.options.getInteger("time_in_hours", true)
    : undefined;
  const expiresAt =
    hours === undefined ? undefined : Date.now() + hours * 60 * 60_000;
  if (expiresAt !== undefined && (!Number.isSafeInteger(expiresAt) || !Number.isFinite(expiresAt))) {
    await replyEphemeral(interaction, "That temporary-ban duration is too large.");
    return;
  }

  const action: ModerationAction = temporary ? "tempban" : "ban";
  const record = await createCase(interaction, store, {
    guildId: interaction.guildId,
    userId: target.id,
    targetName: target.tag,
    moderatorId: interaction.user.id,
    action,
    reason,
    createdAt: Date.now(),
    ...(hours === undefined ? {} : { durationHours: hours, expiresAt }),
  });
  await runRecordedAction(
    interaction,
    store,
    record,
    () => interaction.guild.members.ban(target.id, { reason: auditReason(record) }),
    temporary
      ? `Temporarily banned ${target.tag} for ${hours} hour${hours === 1 ? "" : "s"}.`
      : `Banned ${target.tag} permanently.`,
  );
}

async function kickMember(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const target = interaction.options.getUser("user", true);
  const reason = interaction.options.getString("reason", true).trim();
  if (!(await validateTarget(interaction, target.id, target.tag))) return;
  if (!(await validateReason(interaction, reason))) return;

  const member = await fetchMemberIfPresent(interaction, target.id);
  if (!member) {
    await replyEphemeral(interaction, "That user is not currently in this server.");
    return;
  }
  if (!(await validateMemberHierarchy(interaction, member, "kick"))) return;

  const record = await createCase(interaction, store, {
    guildId: interaction.guildId,
    userId: target.id,
    targetName: target.tag,
    moderatorId: interaction.user.id,
    action: "kick",
    reason,
    createdAt: Date.now(),
  });
  await runRecordedAction(
    interaction,
    store,
    record,
    () => interaction.guild.members.kick(target.id, auditReason(record)),
    `Kicked ${target.tag}.`,
  );
}

async function timeoutMember(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const target = interaction.options.getUser("user", true);
  const minutes = interaction.options.getInteger("time_in_minutes", true);
  const reason = interaction.options.getString("reason", true).trim();
  if (!(await validateTarget(interaction, target.id, target.tag))) return;
  if (!(await validateReason(interaction, reason))) return;
  if (minutes < 1 || minutes > MAX_TIMEOUT_MINUTES) {
    await replyEphemeral(
      interaction,
      `Timeouts must be between 1 and ${MAX_TIMEOUT_MINUTES} minutes.`,
    );
    return;
  }

  const member = await fetchMemberIfPresent(interaction, target.id);
  if (!member) {
    await replyEphemeral(interaction, "That user is not currently in this server.");
    return;
  }
  if (!(await validateMemberHierarchy(interaction, member, "timeout"))) return;

  const record = await createCase(interaction, store, {
    guildId: interaction.guildId,
    userId: target.id,
    targetName: target.tag,
    moderatorId: interaction.user.id,
    action: "timeout",
    reason,
    createdAt: Date.now(),
    durationMinutes: minutes,
    expiresAt: Date.now() + minutes * 60_000,
  });
  await runRecordedAction(
    interaction,
    store,
    record,
    () => member.timeout(minutes * 60_000, auditReason(record)),
    `Timed out ${target.tag} for ${minutes} minute${minutes === 1 ? "" : "s"}.`,
  );
}

async function unbanUser(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const userId = interaction.options.getString("user_id", true).trim();
  if (!/^\d{17,20}$/.test(userId)) {
    await replyEphemeral(interaction, "Enter a valid 17–20 digit Discord user ID.");
    return;
  }

  const record = await createCase(interaction, store, {
    guildId: interaction.guildId,
    userId,
    targetName: userId,
    moderatorId: interaction.user.id,
    action: "unban",
    reason: "Unbanned by moderator.",
    createdAt: Date.now(),
  });
  await runRecordedAction(
    interaction,
    store,
    record,
    () => interaction.guild.members.unban(userId, auditReason(record)),
    `Unbanned user ${userId}.`,
  );
}

async function showCases(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
): Promise<void> {
  const target = interaction.options.getUser("user", true);
  const cases = await store.getModerationCases(interaction.guildId, target.id);
  if (cases.length === 0) {
    await interaction.reply({
      content: `No moderation cases found for ${target.tag}.`,
      flags: EPHEMERAL,
    });
    return;
  }

  await interaction.reply({
    ...buildCaseHistory(target.id, cases, 0, interaction.user.id, target.tag),
    flags: EPHEMERAL,
    allowedMentions: { parse: [] },
  });
}

async function createCase(
  interaction: ChatInputCommandInteraction<"cached">,
  store: BotStore,
  entry: NewModerationCase,
): Promise<ModerationCase> {
  await interaction.deferReply({ flags: EPHEMERAL });
  return store.createModerationCase(entry);
}

async function runRecordedAction(
  interaction: ChatInputCommandInteraction,
  store: BotStore,
  record: ModerationCase,
  action: () => Promise<unknown>,
  successMessage: string,
): Promise<void> {
  try {
    await action();
  } catch (error) {
    await store
      .setModerationCaseStatus(record.caseNumber, "failed", errorMessage(error))
      .catch((storageError: unknown) => {
        logger.error("Could not mark failed moderation case", {
          caseNumber: record.caseNumber,
          error: errorMessage(storageError),
        });
      });
    logger.error("Moderation action failed", {
      caseNumber: record.caseNumber,
      action: record.action,
      error: errorMessage(error),
    });
    await interaction.editReply(
      `Action failed. Case #${record.caseNumber} was saved as failed.`,
    );
    return;
  }

  try {
    await store.setModerationCaseStatus(record.caseNumber, "completed");
  } catch (error) {
    logger.error("Moderation succeeded but case status update failed", {
      caseNumber: record.caseNumber,
      action: record.action,
      error: errorMessage(error),
    });
    await interaction.editReply(
      `${successMessage} Case #${record.caseNumber} was created, but its final status could not be saved.`,
    );
    return;
  }

  await interaction.editReply(`${successMessage} Case #${record.caseNumber}.`);
}

async function fetchMemberIfPresent(
  interaction: ChatInputCommandInteraction<"cached">,
  userId: string,
): Promise<GuildMember | null> {
  try {
    return await interaction.guild.members.fetch(userId);
  } catch (error) {
    if (discordErrorCode(error) === 10007) return null;
    throw error;
  }
}

async function validateTarget(
  interaction: ChatInputCommandInteraction<"cached">,
  userId: string,
  targetName: string,
): Promise<boolean> {
  if (
    userId === interaction.user.id ||
    userId === interaction.client.user?.id ||
    userId === interaction.guild.ownerId
  ) {
    await replyEphemeral(
      interaction,
      `You cannot moderate ${targetName} with this command.`,
    );
    return false;
  }
  return true;
}

async function validateReason(
  interaction: ChatInputCommandInteraction<"cached">,
  reason: string,
): Promise<boolean> {
  if (reason.length > 0) return true;
  await replyEphemeral(interaction, "Enter a non-empty reason.");
  return false;
}

async function validateMemberHierarchy(
  interaction: ChatInputCommandInteraction<"cached">,
  target: GuildMember,
  action: "ban" | "kick" | "timeout",
): Promise<boolean> {
  const isAdministrator =
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) ??
    false;
  if (
    !isAdministrator &&
    target.roles.highest.comparePositionTo(interaction.member.roles.highest) >= 0
  ) {
    await replyEphemeral(
      interaction,
      "You cannot moderate a member whose highest role is equal to or above yours.",
    );
    return false;
  }

  const canBotAct =
    action === "ban"
      ? target.bannable
      : action === "kick"
        ? target.kickable
        : target.moderatable;
  if (!canBotAct) {
    await replyEphemeral(
      interaction,
      `The bot cannot ${action === "timeout" ? "time out" : action} that member. Check the bot's permissions and role position.`,
    );
    return false;
  }
  return true;
}

function hasPermission(
  interaction: BaseInteraction,
  required: bigint,
): boolean {
  return (
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) ===
      true || interaction.memberPermissions?.has(required) === true
  );
}

function canViewCases(interaction: BaseInteraction): boolean {
  return (
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) ===
      true ||
    interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers) ===
      true ||
    interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers) === true ||
    interaction.memberPermissions?.has(PermissionFlagsBits.KickMembers) === true
  );
}

function buildCaseHistory(
  targetId: string,
  cases: ModerationCase[],
  requestedPage: number,
  requesterId: string,
  targetName = cases.find((item) => item.userId === targetId)?.targetName ?? targetId,
) {
  const pageCount = Math.max(1, Math.ceil(cases.length / CASES_PER_PAGE));
  const page = Math.min(Math.max(0, requestedPage), pageCount - 1);
  const visibleCases = cases.slice(
    page * CASES_PER_PAGE,
    (page + 1) * CASES_PER_PAGE,
  );
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`Moderation history: ${targetName}`.slice(0, 256))
    .setDescription(`User ID: ${targetId}`)
    .setFooter({
      text: `Page ${page + 1} of ${pageCount} · ${cases.length} case${cases.length === 1 ? "" : "s"}`,
    });

  for (const moderationCase of visibleCases) {
    const details = [
      `**User:** <@${moderationCase.userId}> (${moderationCase.userId})`,
      `**Moderator:** <@${moderationCase.moderatorId}>`,
      `**Date:** <t:${Math.floor(moderationCase.createdAt / 1000)}:F>`,
      `**Status:** ${moderationCase.status}`,
      `**Reason:** ${moderationCase.reason}`,
    ];
    if (moderationCase.durationMinutes !== undefined) {
      details.push(`**Duration:** ${moderationCase.durationMinutes} minutes`);
    }
    if (moderationCase.durationHours !== undefined) {
      details.push(`**Duration:** ${moderationCase.durationHours} hours`);
    }
    if (moderationCase.expiresAt !== undefined) {
      details.push(
        `**Expires:** <t:${Math.floor(moderationCase.expiresAt / 1000)}:F>`,
      );
    }
    if (moderationCase.failureReason) {
      details.push(`**Failure:** ${moderationCase.failureReason.slice(0, 200)}`);
    }

    embed.addFields({
      name: `Case #${moderationCase.caseNumber} · ${moderationCase.action.toUpperCase()}`,
      value: details.join("\n").slice(0, 1024),
    });
  }

  const components =
    pageCount > 1
      ? [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId(
                `casepage:${requesterId}:${targetId}:${Math.max(0, page - 1)}`,
              )
              .setLabel("Previous")
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(page === 0),
            new ButtonBuilder()
              .setCustomId(
                `casepage:${requesterId}:${targetId}:${Math.min(pageCount - 1, page + 1)}`,
              )
              .setLabel("Next")
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(page === pageCount - 1),
          ),
        ]
      : [];

  return { embeds: [embed], components };
}

function automaticUnbanCase(
  client: Client,
  job: TempBanJob,
  alreadyUnbanned = false,
): NewModerationCase {
  return {
    guildId: job.guildId,
    userId: job.userId,
    targetName: job.targetName,
    moderatorId: client.user?.id ?? "bot",
    action: "unban",
    reason: alreadyUnbanned
      ? `Temporary ban from Case #${job.caseNumber} expired; the ban had already been removed.`
      : `Temporary ban from Case #${job.caseNumber} expired automatically.`,
    createdAt: Date.now(),
  };
}

function auditReason(record: ModerationCase): string {
  return `Case #${record.caseNumber}: ${record.reason}`;
}

function discordErrorCode(error: unknown): number | undefined {
  if (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (typeof error.code === "number" || typeof error.code === "string")
  ) {
    const code = Number(error.code);
    return Number.isFinite(code) ? code : undefined;
  }
  return undefined;
}

async function replyEphemeral(
  interaction: ChatInputCommandInteraction,
  content: string,
): Promise<void> {
  if (interaction.deferred || interaction.replied) {
    await interaction.editReply({ content });
  } else {
    await interaction.reply({ content, flags: EPHEMERAL });
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}