import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import type { PollRecord } from "./storage.js";

export function buildPollEmbed(poll: PollRecord): EmbedBuilder {
  const totals = poll.options.map(
    (_, optionIndex) =>
      Object.values(poll.votes).filter((vote) => vote === optionIndex).length,
  );
  const totalVotes = totals.reduce((total, count) => total + count, 0);
  const choices = poll.options
    .map(
      (option, index) =>
        `**${index + 1}. ${option}** — ${totals[index]} vote${totals[index] === 1 ? "" : "s"}`,
    )
    .join("\n");

  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(poll.question)
    .setDescription(choices)
    .setFooter({
      text: `${totalVotes} total vote${totalVotes === 1 ? "" : "s"} · Click again to remove your vote`,
    });
}

export function buildPollComponents(
  poll: PollRecord,
): ActionRowBuilder<ButtonBuilder> {
  const row = new ActionRowBuilder<ButtonBuilder>();
  poll.options.forEach((option, index) => {
    const votes = Object.values(poll.votes).filter((vote) => vote === index).length;
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`poll:${poll.id}:${index}`)
        .setLabel(`${option} · ${votes}`)
        .setStyle(ButtonStyle.Primary),
    );
  });
  return row;
}