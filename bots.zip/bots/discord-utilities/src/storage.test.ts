import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import {
  BotStore,
  ECONOMY_COOLDOWNS_MS,
  type NewModerationCase,
  type VerificationSetup,
} from "./storage.js";

test("migrates existing poll and reminder data and persists temp-ban jobs", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const filePath = join(directory, "bot-state.json");
    const legacyState = {
      polls: {
        poll1: {
          id: "poll1",
          guildId: "guild1",
          channelId: "channel1",
          messageId: "message1",
          question: "Question?",
          options: ["Yes", "No"],
          votes: {},
          createdAt: 1,
        },
      },
      reminders: [
        {
          id: "reminder1",
          guildId: "guild1",
          channelId: "channel1",
          userId: "user1",
          text: "Remember",
          dueAt: 2,
        },
      ],
    };
    await writeFile(filePath, JSON.stringify(legacyState), "utf8");

    let store = new BotStore(filePath);
    await store.initialize();
    const tempBan = await store.createModerationCase({
      guildId: "guild1",
      userId: "12345678901234567",
      targetName: "Member",
      moderatorId: "22345678901234567",
      action: "tempban",
      reason: "Test reason",
      createdAt: 10,
      durationHours: 1,
      expiresAt: 3_600_010,
    });

    store = new BotStore(filePath);
    await store.initialize();
    assert.deepEqual(await store.getDueTempBans(3_600_010), [
      {
        guildId: "guild1",
        userId: "12345678901234567",
        targetName: "Member",
        caseNumber: tempBan.caseNumber,
        dueAt: 3_600_010,
      },
    ]);

    await store.setModerationCaseStatus(tempBan.caseNumber, "completed");
    const automaticUnban = await store.finishTempBan(
      tempBan.caseNumber,
      automaticUnbanEntry(),
    );
    assert.equal(automaticUnban.caseNumber, tempBan.caseNumber + 1);
    assert.deepEqual(await store.getDueTempBans(3_600_010), []);

    const persisted = JSON.parse(await readFile(filePath, "utf8")) as {
      polls: Record<string, unknown>;
      reminders: unknown[];
      moderationCases: { caseNumber: number }[];
    };
    assert.ok(persisted.polls.poll1);
    assert.equal(persisted.reminders.length, 1);
    assert.deepEqual(
      persisted.moderationCases.map((item) => item.caseNumber),
      [tempBan.caseNumber, automaticUnban.caseNumber],
    );
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("allocates unique sequential case numbers during concurrent writes", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const store = new BotStore(join(directory, "bot-state.json"));
    await store.initialize();
    const cases = await Promise.all(
      Array.from({ length: 12 }, (_, index) =>
        store.createModerationCase({
          ...automaticUnbanEntry(),
          userId: `${index}`,
          action: "ban",
        }),
      ),
    );

    assert.deepEqual(
      cases.map((item) => item.caseNumber).sort((a, b) => a - b),
      Array.from({ length: 12 }, (_, index) => index + 1),
    );
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("awards XP at most once per minute and persists the updated level", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const filePath = join(directory, "bot-state.json");
    const store = new BotStore(filePath);
    await store.initialize();

    const firstAward = await store.awardMessageXp("guild1", "user1", 80, 100_000);
    assert.equal(firstAward?.xp, 80);
    assert.equal(firstAward?.level, 1);
    assert.equal(
      await store.awardMessageXp("guild1", "user1", 20, 159_999),
      undefined,
    );
    const secondAward = await store.awardMessageXp(
      "guild1",
      "user1",
      20,
      160_000,
    );
    assert.equal(secondAward?.xp, 100);
    assert.equal(secondAward?.level, 2);

    const reloadedStore = new BotStore(filePath);
    await reloadedStore.initialize();
    const reloaded = await reloadedStore.getEconomyProfile("guild1", "user1");
    assert.equal(reloaded.xp, 100);
    assert.equal(reloaded.level, 2);
    assert.equal(reloaded.lastXpAwardAt, 160_000);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("daily, work, and crime cooldowns reject early claims and reopen on time", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const filePath = join(directory, "bot-state.json");
    let store = new BotStore(filePath);
    await store.initialize();
    const now = 1_000_000;

    const daily = await store.performEconomyAction(
      "guild1",
      "user1",
      "daily",
      500,
      now,
    );
    assert.equal(daily.accepted, true);
    assert.equal(daily.profile.credits, 500);
    const earlyDaily = await store.performEconomyAction(
      "guild1",
      "user1",
      "daily",
      500,
      now + ECONOMY_COOLDOWNS_MS.daily - 1,
    );
    assert.equal(earlyDaily.accepted, false);
    assert.equal(earlyDaily.remainingMs, 1);

    store = new BotStore(filePath);
    await store.initialize();
    const dailyReady = await store.performEconomyAction(
      "guild1",
      "user1",
      "daily",
      500,
      now + ECONOMY_COOLDOWNS_MS.daily,
    );
    assert.equal(dailyReady.accepted, true);
    assert.equal(dailyReady.profile.credits, 1_000);

    const work = await store.performEconomyAction(
      "guild1",
      "user1",
      "work",
      250,
      now,
    );
    assert.equal(work.accepted, true);
    const earlyWork = await store.performEconomyAction(
      "guild1",
      "user1",
      "work",
      250,
      now + ECONOMY_COOLDOWNS_MS.work - 1,
    );
    assert.equal(earlyWork.accepted, false);
    assert.equal(earlyWork.remainingMs, 1);
    const workReady = await store.performEconomyAction(
      "guild1",
      "user1",
      "work",
      250,
      now + ECONOMY_COOLDOWNS_MS.work,
    );
    assert.equal(workReady.accepted, true);

    const crime = await store.performEconomyAction(
      "guild1",
      "user1",
      "crime",
      -150,
      now,
    );
    assert.equal(crime.accepted, true);
    const earlyCrime = await store.performEconomyAction(
      "guild1",
      "user1",
      "crime",
      200,
      now + ECONOMY_COOLDOWNS_MS.crime - 1,
    );
    assert.equal(earlyCrime.accepted, false);
    assert.equal(earlyCrime.remainingMs, 1);
    const crimeReady = await store.performEconomyAction(
      "guild1",
      "user1",
      "crime",
      200,
      now + ECONOMY_COOLDOWNS_MS.crime,
    );
    assert.equal(crimeReady.accepted, true);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("shop purchases are atomic, respect balances, and persist inventory and pass expiry", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const filePath = join(directory, "bot-state.json");
    const profile = (userId: string, credits: number) => ({
      guildId: "guild1",
      userId,
      xp: 0,
      level: 1,
      credits,
      lastXpAwardAt: 0,
      dailyCooldownUntil: 0,
      workCooldownUntil: 0,
      crimeCooldownUntil: 0,
    });
    await writeFile(
      filePath,
      JSON.stringify({
        polls: {},
        reminders: [],
        economyProfiles: {
          "guild1:user1": profile("user1", 6_000),
          "guild1:user2": profile("user2", 10_000),
        },
      }),
      "utf8",
    );

    const store = new BotStore(filePath);
    await store.initialize();
    assert.deepEqual(
      (await store.getEconomyProfile("guild1", "user1")).inventory,
      [],
    );
    assert.deepEqual(
      (await store.getEconomyProfile("guild1", "user1")).badges,
      [],
    );

    const now = 2_000_000;
    const simultaneousPurchases = await Promise.all([
      store.purchaseShopItem(
        "guild1",
        "user1",
        "fennec-body",
        5_000,
        undefined,
        now,
      ),
      store.purchaseShopItem(
        "guild1",
        "user1",
        "fennec-body",
        5_000,
        undefined,
        now,
      ),
    ]);
    assert.deepEqual(
      simultaneousPurchases.map((result) => result.status).sort(),
      ["already_owned", "purchased"],
    );
    const insufficientFunds = await store.purchaseShopItem(
      "guild1",
      "user1",
      "titanium-white-octane",
      15_000,
      undefined,
      now,
    );
    assert.equal(insufficientFunds.status, "insufficient_credits");
    assert.equal(insufficientFunds.profile.credits, 1_000);

    const nicknamePass = await store.purchaseShopItem(
      "guild1",
      "user2",
      "nickname-troll",
      3_500,
      ECONOMY_COOLDOWNS_MS.daily,
      now,
    );
    assert.equal(nicknamePass.status, "purchased");
    assert.equal(
      nicknamePass.profile.inventory[0]?.expiresAt,
      now + ECONOMY_COOLDOWNS_MS.daily,
    );
    const activePassPurchase = await store.purchaseShopItem(
      "guild1",
      "user2",
      "nickname-troll",
      3_500,
      ECONOMY_COOLDOWNS_MS.daily,
      now + ECONOMY_COOLDOWNS_MS.daily - 1,
    );
    assert.equal(activePassPurchase.status, "already_owned");
    const renewedPass = await store.purchaseShopItem(
      "guild1",
      "user2",
      "nickname-troll",
      3_500,
      ECONOMY_COOLDOWNS_MS.daily,
      now + ECONOMY_COOLDOWNS_MS.daily,
    );
    assert.equal(renewedPass.status, "purchased");
    assert.equal(renewedPass.profile.credits, 3_000);
    assert.equal(renewedPass.profile.inventory.length, 1);

    const reloadedStore = new BotStore(filePath);
    await reloadedStore.initialize();
    const persistedVehicle = await reloadedStore.getEconomyProfile(
      "guild1",
      "user1",
    );
    assert.equal(persistedVehicle.credits, 1_000);
    assert.equal(persistedVehicle.inventory[0]?.itemId, "fennec-body");
    const persistedPass = await reloadedStore.getEconomyProfile(
      "guild1",
      "user2",
    );
    assert.equal(persistedPass.credits, 3_000);
    assert.equal(persistedPass.inventory[0]?.expiresAt, now + 2 * ECONOMY_COOLDOWNS_MS.daily);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("badge purchases are atomic and staff grants persist without duplicates", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const filePath = join(directory, "bot-state.json");
    const profile = (userId: string, credits: number) => ({
      guildId: "guild1",
      userId,
      xp: 0,
      level: 1,
      credits,
      lastXpAwardAt: 0,
      dailyCooldownUntil: 0,
      workCooldownUntil: 0,
      crimeCooldownUntil: 0,
    });
    await writeFile(
      filePath,
      JSON.stringify({
        polls: {},
        reminders: [],
        economyProfiles: {
          "guild1:buyer": profile("buyer", 5_000),
          "guild1:broke": profile("broke", 999),
        },
      }),
      "utf8",
    );

    const store = new BotStore(filePath);
    await store.initialize();

    const simultaneousPurchases = await Promise.all([
      store.purchaseBadge("guild1", "buyer", "first-touch", 1_000),
      store.purchaseBadge("guild1", "buyer", "first-touch", 1_000),
    ]);
    assert.deepEqual(
      simultaneousPurchases.map((result) => result.status).sort(),
      ["already_owned", "purchased"],
    );
    const purchasedProfile = await store.getEconomyProfile("guild1", "buyer");
    assert.equal(purchasedProfile.credits, 4_000);
    assert.deepEqual(purchasedProfile.badges, ["first-touch"]);

    const insufficient = await store.purchaseBadge(
      "guild1",
      "broke",
      "goal-getter",
      4_000,
    );
    assert.equal(insufficient.status, "insufficient_credits");
    assert.equal(insufficient.profile.credits, 999);
    assert.deepEqual(insufficient.profile.badges, []);

    const grant = await store.grantBadge(
      "guild1",
      "winner",
      "tournament-winner",
    );
    assert.equal(grant.status, "granted");
    const duplicateGrant = await store.grantBadge(
      "guild1",
      "winner",
      "tournament-winner",
    );
    assert.equal(duplicateGrant.status, "already_owned");
    await store.grantBadge("guild1", "winner", "server-veteran");

    const reloadedStore = new BotStore(filePath);
    await reloadedStore.initialize();
    const persistedBuyer = await reloadedStore.getEconomyProfile(
      "guild1",
      "buyer",
    );
    assert.equal(persistedBuyer.credits, 4_000);
    assert.deepEqual(persistedBuyer.badges, ["first-touch"]);
    const persistedWinner = await reloadedStore.getEconomyProfile(
      "guild1",
      "winner",
    );
    assert.deepEqual(persistedWinner.badges, [
      "tournament-winner",
      "server-veteran",
    ]);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("verification panel settings and role assignments persist across restarts", async () => {
  const directory = await mkdtemp(join(tmpdir(), "discord-utilities-store-"));
  try {
    const filePath = join(directory, "bot-state.json");
    const store = new BotStore(filePath);
    await store.initialize();
    const setup: VerificationSetup = {
      guildId: "guild1",
      channelId: "channel1",
      messageId: "message1",
      createdAt: 123_456,
    };
    await store.saveVerificationSetup(setup);
    await store.setVerificationRole(
      setup.guildId,
      setup.messageId,
      "verified-role-id",
    );

    const reloadedStore = new BotStore(filePath);
    await reloadedStore.initialize();
    assert.deepEqual(
      await reloadedStore.getVerificationSetup(
        setup.guildId,
        setup.messageId,
      ),
      { ...setup, verifiedRoleId: "verified-role-id" },
    );
    assert.equal(
      await reloadedStore.getVerificationSetup(setup.guildId, "old-message"),
      undefined,
    );
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

function automaticUnbanEntry(): NewModerationCase {
  return {
    guildId: "guild1",
    userId: "12345678901234567",
    targetName: "Member",
    moderatorId: "32345678901234567",
    action: "unban",
    reason: "Temporary ban expired.",
    createdAt: 20,
  };
}