import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export interface PollRecord {
  id: string;
  guildId: string;
  channelId: string;
  messageId: string;
  question: string;
  options: string[];
  votes: Record<string, number>;
  createdAt: number;
}

export interface ReminderRecord {
  id: string;
  guildId: string;
  channelId: string;
  userId: string;
  text: string;
  dueAt: number;
}

export type ModerationAction =
  | "ban"
  | "kick"
  | "timeout"
  | "tempban"
  | "unban";

export type ModerationCaseStatus = "pending" | "completed" | "failed";

export interface ModerationCase {
  caseNumber: number;
  guildId: string;
  userId: string;
  targetName: string;
  moderatorId: string;
  action: ModerationAction;
  reason: string;
  createdAt: number;
  status: ModerationCaseStatus;
  durationMinutes?: number;
  durationHours?: number;
  expiresAt?: number;
  failureReason?: string;
}

export type NewModerationCase = Omit<
  ModerationCase,
  "caseNumber" | "status"
>;

export interface TempBanJob {
  guildId: string;
  userId: string;
  targetName: string;
  caseNumber: number;
  dueAt: number;
}

export interface EconomyProfile {
  guildId: string;
  userId: string;
  xp: number;
  level: number;
  credits: number;
  lastXpAwardAt: number;
  dailyCooldownUntil: number;
  workCooldownUntil: number;
  crimeCooldownUntil: number;
  favoriteVehicle?: string;
  inventory: ShopInventoryItem[];
  badges: string[];
}

export interface ShopInventoryItem {
  itemId: string;
  purchasedAt: number;
  expiresAt?: number;
}

export type EconomyAction = "daily" | "work" | "crime";

export type ShopPurchaseStatus =
  | "purchased"
  | "insufficient_credits"
  | "already_owned";

export interface ShopPurchaseResult {
  status: ShopPurchaseStatus;
  profile: EconomyProfile;
}

export type BadgePurchaseStatus = ShopPurchaseStatus;

export interface BadgePurchaseResult {
  status: BadgePurchaseStatus;
  profile: EconomyProfile;
}

export interface BadgeGrantResult {
  status: "granted" | "already_owned";
  profile: EconomyProfile;
}

export interface VerificationSetup {
  guildId: string;
  channelId: string;
  messageId: string;
  createdAt: number;
  verifiedRoleId?: string;
}

export interface EconomyActionResult {
  accepted: boolean;
  remainingMs: number;
  creditsChange: number;
  profile: EconomyProfile;
}

export const ECONOMY_COOLDOWNS_MS: Record<EconomyAction, number> = {
  daily: 24 * 60 * 60_000,
  work: 30 * 60_000,
  crime: 30 * 60_000,
};

interface BotState {
  polls: Record<string, PollRecord>;
  reminders: ReminderRecord[];
  moderationCases: ModerationCase[];
  nextCaseNumber: number;
  tempBans: TempBanJob[];
  economyProfiles: Record<string, EconomyProfile>;
  verificationSetups: Record<string, VerificationSetup>;
}

const initialState = (): BotState => ({
  polls: {},
  reminders: [],
  moderationCases: [],
  nextCaseNumber: 1,
  tempBans: [],
  economyProfiles: {},
  verificationSetups: {},
});

export class BotStore {
  private state = initialState();
  private writeQueue: Promise<void> = Promise.resolve();
  private readonly filePath: string;

  constructor(
    filePath = resolve(
      dirname(fileURLToPath(import.meta.url)),
      "../data/bot-state.json",
    ),
  ) {
    this.filePath = filePath;
  }

  async initialize(): Promise<void> {
    await mkdir(dirname(this.filePath), { recursive: true });

    try {
      const raw = await readFile(this.filePath, "utf8");
      const parsed: unknown = JSON.parse(raw);
      if (!isObject(parsed) || !isObject(parsed.polls) || !Array.isArray(parsed.reminders)) {
        throw new Error("The bot state file has an unexpected format.");
      }

      const moderationCases = Array.isArray(parsed.moderationCases)
        ? (parsed.moderationCases as ModerationCase[])
        : [];
      const largestCaseNumber = moderationCases.reduce(
        (largest, item) =>
          Number.isSafeInteger(item.caseNumber)
            ? Math.max(largest, item.caseNumber)
            : largest,
        0,
      );
      const savedNextCaseNumber = parsed.nextCaseNumber;
      this.state = {
        polls: parsed.polls as Record<string, PollRecord>,
        reminders: parsed.reminders as ReminderRecord[],
        moderationCases,
        nextCaseNumber:
          typeof savedNextCaseNumber === "number" &&
          Number.isSafeInteger(savedNextCaseNumber) &&
          savedNextCaseNumber > largestCaseNumber
            ? savedNextCaseNumber
            : largestCaseNumber + 1,
        tempBans: Array.isArray(parsed.tempBans)
          ? (parsed.tempBans as TempBanJob[])
          : [],
        economyProfiles: normalizeEconomyProfiles(parsed.economyProfiles),
        verificationSetups: normalizeVerificationSetups(
          parsed.verificationSetups,
        ),
      };
      await this.persist(this.state);
    } catch (error) {
      if (isMissingFile(error)) {
        await this.persist(this.state);
        return;
      }
      throw error;
    }
  }

  async addPoll(poll: PollRecord): Promise<void> {
    await this.update((draft) => {
      draft.polls[poll.id] = poll;
    });
  }

  async getPoll(id: string): Promise<PollRecord | undefined> {
    await this.writeQueue;
    const poll = this.state.polls[id];
    return poll ? structuredClone(poll) : undefined;
  }

  async castVote(
    pollId: string,
    userId: string,
    optionIndex: number,
  ): Promise<PollRecord | undefined> {
    return this.update((draft) => {
      const poll = draft.polls[pollId];
      if (!poll || optionIndex < 0 || optionIndex >= poll.options.length) {
        return undefined;
      }

      if (poll.votes[userId] === optionIndex) {
        delete poll.votes[userId];
      } else {
        poll.votes[userId] = optionIndex;
      }
      return structuredClone(poll);
    });
  }

  async addReminder(reminder: ReminderRecord): Promise<void> {
    await this.update((draft) => {
      draft.reminders.push(reminder);
    });
  }

  async getDueReminders(now = Date.now()): Promise<ReminderRecord[]> {
    await this.writeQueue;
    return structuredClone(
      this.state.reminders.filter((reminder) => reminder.dueAt <= now),
    );
  }

  async removeReminder(id: string): Promise<void> {
    await this.update((draft) => {
      draft.reminders = draft.reminders.filter((reminder) => reminder.id !== id);
    });
  }

  async rescheduleReminder(id: string, dueAt: number): Promise<void> {
    await this.update((draft) => {
      const reminder = draft.reminders.find((item) => item.id === id);
      if (reminder) reminder.dueAt = dueAt;
    });
  }

  async createModerationCase(
    entry: NewModerationCase,
  ): Promise<ModerationCase> {
    return this.update((draft) => {
      const moderationCase: ModerationCase = {
        ...entry,
        caseNumber: draft.nextCaseNumber,
        status: "pending",
      };
      draft.nextCaseNumber += 1;
      draft.moderationCases.push(moderationCase);

      if (entry.action === "tempban" && entry.expiresAt !== undefined) {
        draft.tempBans.push({
          guildId: entry.guildId,
          userId: entry.userId,
          targetName: entry.targetName,
          caseNumber: moderationCase.caseNumber,
          dueAt: entry.expiresAt,
        });
      }

      return structuredClone(moderationCase);
    });
  }

  async getModerationCases(
    guildId: string,
    userId: string,
  ): Promise<ModerationCase[]> {
    await this.writeQueue;
    return structuredClone(
      this.state.moderationCases
        .filter((item) => item.guildId === guildId && item.userId === userId)
        .sort((a, b) => b.caseNumber - a.caseNumber),
    );
  }

  async setModerationCaseStatus(
    caseNumber: number,
    status: ModerationCaseStatus,
    failureReason?: string,
  ): Promise<void> {
    await this.update((draft) => {
      const moderationCase = draft.moderationCases.find(
        (item) => item.caseNumber === caseNumber,
      );
      if (!moderationCase) {
        throw new Error(`Moderation case #${caseNumber} was not found.`);
      }
      moderationCase.status = status;
      if (failureReason) moderationCase.failureReason = failureReason;
      if (status === "failed") {
        draft.tempBans = draft.tempBans.filter(
          (item) => item.caseNumber !== caseNumber,
        );
      }
    });
  }

  async getDueTempBans(now = Date.now()): Promise<TempBanJob[]> {
    await this.writeQueue;
    return structuredClone(
      this.state.tempBans.filter((job) => job.dueAt <= now),
    );
  }

  async rescheduleTempBan(caseNumber: number, dueAt: number): Promise<void> {
    await this.update((draft) => {
      const job = draft.tempBans.find((item) => item.caseNumber === caseNumber);
      if (job) job.dueAt = dueAt;
    });
  }

  async finishTempBan(
    caseNumber: number,
    automaticUnbanCase: NewModerationCase,
  ): Promise<ModerationCase> {
    return this.update((draft) => {
      draft.tempBans = draft.tempBans.filter(
        (item) => item.caseNumber !== caseNumber,
      );
      const unbanCase: ModerationCase = {
        ...automaticUnbanCase,
        caseNumber: draft.nextCaseNumber,
        status: "completed",
      };
      draft.nextCaseNumber += 1;
      draft.moderationCases.push(unbanCase);
      return structuredClone(unbanCase);
    });
  }

  async getEconomyProfile(
    guildId: string,
    userId: string,
  ): Promise<EconomyProfile> {
    await this.writeQueue;
    const profile =
      this.state.economyProfiles[economyProfileKey(guildId, userId)] ??
      createEconomyProfile(guildId, userId);
    return structuredClone(profile);
  }

  async getEconomyLeaderboard(guildId: string): Promise<EconomyProfile[]> {
    await this.writeQueue;
    return structuredClone(
      Object.values(this.state.economyProfiles).filter(
        (profile) => profile.guildId === guildId,
      ),
    );
  }

  async awardMessageXp(
    guildId: string,
    userId: string,
    xpAmount: number,
    now = Date.now(),
  ): Promise<EconomyProfile | undefined> {
    return this.updateIfChanged((draft) => {
      const key = economyProfileKey(guildId, userId);
      const existing = draft.economyProfiles[key];
      if (
        existing &&
        existing.lastXpAwardAt > 0 &&
        now - existing.lastXpAwardAt < 60_000
      ) {
        return { result: undefined, changed: false };
      }

      const profile = existing ?? createEconomyProfile(guildId, userId);
      profile.xp += xpAmount;
      profile.level = levelFromXp(profile.xp);
      profile.lastXpAwardAt = now;
      draft.economyProfiles[key] = profile;
      return { result: structuredClone(profile), changed: true };
    });
  }

  async performEconomyAction(
    guildId: string,
    userId: string,
    action: EconomyAction,
    requestedCreditsChange: number,
    now = Date.now(),
  ): Promise<EconomyActionResult> {
    return this.update((draft) => {
      const key = economyProfileKey(guildId, userId);
      const profile =
        draft.economyProfiles[key] ?? createEconomyProfile(guildId, userId);
      const cooldownField = `${action}CooldownUntil` as const;
      const currentCooldownUntil = profile[cooldownField];

      if (currentCooldownUntil > now) {
        return {
          accepted: false,
          remainingMs: currentCooldownUntil - now,
          creditsChange: 0,
          profile: structuredClone(profile),
        };
      }

      profile[cooldownField] = now + ECONOMY_COOLDOWNS_MS[action];
      const nextCredits = Math.max(0, profile.credits + requestedCreditsChange);
      const actualCreditsChange = nextCredits - profile.credits;
      profile.credits = nextCredits;
      draft.economyProfiles[key] = profile;

      return {
        accepted: true,
        remainingMs: 0,
        creditsChange: actualCreditsChange,
        profile: structuredClone(profile),
      };
    });
  }

  async setFavoriteVehicle(
    guildId: string,
    userId: string,
    favoriteVehicle: string | null,
  ): Promise<EconomyProfile> {
    return this.update((draft) => {
      const key = economyProfileKey(guildId, userId);
      const profile =
        draft.economyProfiles[key] ?? createEconomyProfile(guildId, userId);
      if (favoriteVehicle) {
        profile.favoriteVehicle = favoriteVehicle;
      } else {
        delete profile.favoriteVehicle;
      }
      draft.economyProfiles[key] = profile;
      return structuredClone(profile);
    });
  }

  async purchaseShopItem(
    guildId: string,
    userId: string,
    itemId: string,
    cost: number,
    durationMs?: number,
    now = Date.now(),
  ): Promise<ShopPurchaseResult> {
    if (!Number.isSafeInteger(cost) || cost <= 0) {
      throw new Error("Shop item cost must be a positive whole number.");
    }
    if (
      durationMs !== undefined &&
      (!Number.isSafeInteger(durationMs) || durationMs <= 0)
    ) {
      throw new Error("Shop item duration must be a positive whole number.");
    }

    return this.updateIfChanged<ShopPurchaseResult>((draft) => {
      const key = economyProfileKey(guildId, userId);
      const profile =
        draft.economyProfiles[key] ?? createEconomyProfile(guildId, userId);
      const existingIndex = profile.inventory.findIndex(
        (item) => item.itemId === itemId,
      );
      const existingItem =
        existingIndex >= 0 ? profile.inventory[existingIndex] : undefined;
      if (
        existingItem &&
        (existingItem.expiresAt === undefined || existingItem.expiresAt > now)
      ) {
        return {
          result: { status: "already_owned", profile: structuredClone(profile) },
          changed: false,
        };
      }

      if (profile.credits < cost) {
        return {
          result: {
            status: "insufficient_credits",
            profile: structuredClone(profile),
          },
          changed: false,
        };
      }

      profile.credits -= cost;
      const inventoryItem: ShopInventoryItem = {
        itemId,
        purchasedAt: now,
        ...(durationMs === undefined ? {} : { expiresAt: now + durationMs }),
      };
      if (existingIndex >= 0) {
        profile.inventory[existingIndex] = inventoryItem;
      } else {
        profile.inventory.push(inventoryItem);
      }
      draft.economyProfiles[key] = profile;

      return {
        result: { status: "purchased", profile: structuredClone(profile) },
        changed: true,
      };
    });
  }

  async purchaseBadge(
    guildId: string,
    userId: string,
    badgeId: string,
    cost: number,
  ): Promise<BadgePurchaseResult> {
    if (!Number.isSafeInteger(cost) || cost <= 0) {
      throw new Error("Badge cost must be a positive whole number.");
    }

    return this.updateIfChanged<BadgePurchaseResult>((draft) => {
      const key = economyProfileKey(guildId, userId);
      const profile =
        draft.economyProfiles[key] ?? createEconomyProfile(guildId, userId);
      if (profile.badges.includes(badgeId)) {
        return {
          result: { status: "already_owned", profile: structuredClone(profile) },
          changed: false,
        };
      }
      if (profile.credits < cost) {
        return {
          result: {
            status: "insufficient_credits",
            profile: structuredClone(profile),
          },
          changed: false,
        };
      }

      profile.credits -= cost;
      profile.badges.push(badgeId);
      draft.economyProfiles[key] = profile;
      return {
        result: { status: "purchased", profile: structuredClone(profile) },
        changed: true,
      };
    });
  }

  async grantBadge(
    guildId: string,
    userId: string,
    badgeId: string,
  ): Promise<BadgeGrantResult> {
    if (!badgeId.trim()) {
      throw new Error("Badge ID must not be empty.");
    }

    return this.updateIfChanged<BadgeGrantResult>((draft) => {
      const key = economyProfileKey(guildId, userId);
      const profile =
        draft.economyProfiles[key] ?? createEconomyProfile(guildId, userId);
      if (profile.badges.includes(badgeId)) {
        return {
          result: { status: "already_owned", profile: structuredClone(profile) },
          changed: false,
        };
      }

      profile.badges.push(badgeId);
      draft.economyProfiles[key] = profile;
      return {
        result: { status: "granted", profile: structuredClone(profile) },
        changed: true,
      };
    });
  }

  async saveVerificationSetup(setup: VerificationSetup): Promise<void> {
    await this.update((draft) => {
      draft.verificationSetups[verificationSetupKey(setup.guildId, setup.messageId)] =
        setup;
    });
  }

  async getVerificationSetup(
    guildId: string,
    messageId: string,
  ): Promise<VerificationSetup | undefined> {
    await this.writeQueue;
    const setup =
      this.state.verificationSetups[
        verificationSetupKey(guildId, messageId)
      ];
    return setup ? structuredClone(setup) : undefined;
  }

  async setVerificationRole(
    guildId: string,
    messageId: string,
    roleId: string,
  ): Promise<void> {
    await this.update((draft) => {
      const setup =
        draft.verificationSetups[
          verificationSetupKey(guildId, messageId)
        ];
      if (!setup) {
        throw new Error("Verification panel settings were not found.");
      }
      setup.verifiedRoleId = roleId;
    });
  }

  private async update<T>(change: (draft: BotState) => T): Promise<T> {
    return this.updateIfChanged((draft) => ({
      result: change(draft),
      changed: true,
    }));
  }

  private async updateIfChanged<T>(
    change: (draft: BotState) => { result: T; changed: boolean },
  ): Promise<T> {
    const operation = this.writeQueue.then(async () => {
      const previous = this.state;
      const draft = structuredClone(previous);
      const { result, changed } = change(draft);
      if (!changed) return result;
      this.state = draft;

      try {
        await this.persist(draft);
        return result;
      } catch (error) {
        this.state = previous;
        throw error;
      }
    });

    this.writeQueue = operation.then(
      () => undefined,
      () => undefined,
    );
    return operation;
  }

  private async persist(state: BotState): Promise<void> {
    const temporaryPath = `${this.filePath}.${process.pid}.tmp`;
    await writeFile(temporaryPath, `${JSON.stringify(state, null, 2)}\n`, "utf8");
    await rename(temporaryPath, this.filePath);
  }
}

export function levelFromXp(totalXp: number): number {
  return Math.floor(Math.max(0, totalXp) / 100) + 1;
}

function createEconomyProfile(guildId: string, userId: string): EconomyProfile {
  return {
    guildId,
    userId,
    xp: 0,
    level: 1,
    credits: 0,
    lastXpAwardAt: 0,
    dailyCooldownUntil: 0,
    workCooldownUntil: 0,
    crimeCooldownUntil: 0,
    inventory: [],
    badges: [],
  };
}

function economyProfileKey(guildId: string, userId: string): string {
  return `${guildId}:${userId}`;
}

function verificationSetupKey(guildId: string, messageId: string): string {
  return `${guildId}:${messageId}`;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isMissingFile(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    error.code === "ENOENT"
  );
}

function normalizeEconomyProfiles(
  value: unknown,
): Record<string, EconomyProfile> {
  if (!isObject(value)) return {};

  const profiles: Record<string, EconomyProfile> = {};
  for (const [key, candidate] of Object.entries(value)) {
    if (!isObject(candidate)) continue;
    profiles[key] = {
      ...(candidate as unknown as EconomyProfile),
      inventory: Array.isArray(candidate.inventory)
        ? (candidate.inventory as ShopInventoryItem[])
        : [],
      badges: Array.isArray(candidate.badges)
        ? candidate.badges.filter(
            (badge): badge is string => typeof badge === "string",
          )
        : [],
    };
  }
  return profiles;
}

function normalizeVerificationSetups(
  value: unknown,
): Record<string, VerificationSetup> {
  if (!isObject(value)) return {};

  const setups: Record<string, VerificationSetup> = {};
  for (const [key, candidate] of Object.entries(value)) {
    if (
      isObject(candidate) &&
      typeof candidate.guildId === "string" &&
      typeof candidate.channelId === "string" &&
      typeof candidate.messageId === "string" &&
      typeof candidate.createdAt === "number"
    ) {
      setups[key] = candidate as unknown as VerificationSetup;
    }
  }
  return setups;
}