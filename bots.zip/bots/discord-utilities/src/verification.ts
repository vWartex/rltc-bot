import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  SlashCommandBuilder,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type Guild,
  type Role,
} from "discord.js";
import { logger } from "./logger.js";
import { BotStore, type VerificationSetup } from "./storage.js";

const VERIFY_BUTTON_ID = "verify:member";
const VERIFIED_ROLE_NAME = "Verified";
const UNVERIFIED_ROLE_NAME = "Un-Verified";
const GRAY_ROLE_COLOR = 0x808080;

const roleCreationByGuild = new Map<string, Promise<Role>>();

export const verificationSlashCommands = [
  new SlashCommandBuilder()
    .setName("setup-verify")
    .setDescription("Post the server's member verification panel.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
].map((command) => command.toJSON());

export async function handleSetupVerify(
  interaction: ChatInputCommandInteraction,
  store: BotStore,
): Promise<void> {
  if (!interaction.inCachedGuild()) {
    await interaction.reply({
      content: "Verification panels can only be set up in a server.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!interaction.memberPermissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({
      content: "Only server administrators can set up verification.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const channel = interaction.channel;
  if (!channel?.isSendable()) {
    await interaction.reply({
      content: "I can't post a verification panel in this channel.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const embed = new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle("Server Verification")
    .setDescription(
      "Welcome to the server! To access all channels and protect the server from bots, please click the green button below.",
    )
    .setFooter({ text: "One click verifies your server membership." });
  const button = new ButtonBuilder()
    .setCustomId(VERIFY_BUTTON_ID)
    .setLabel("Verify")
    .setEmoji("✅")
    .setStyle(ButtonStyle.Success);
  const panel = await channel.send({
    embeds: [embed],
    components: [new ActionRowBuilder<ButtonBuilder>().addComponents(button)],
  });

  const setup: VerificationSetup = {
    guildId: interaction.guildId,
    channelId: interaction.channelId,
    messageId: panel.id,
    createdAt: Date.now(),
  };
  try {
    await store.saveVerificationSetup(setup);
  } catch (error) {
    await panel.delete().catch(() => {});
    throw error;
  }

  await interaction.editReply(
    "Verification panel posted and saved. The server needs an `Un-Verified` role, and my bot role must be above both verification roles.",
  );
}

export async function handleVerificationButton(
  interaction: ButtonInteraction,
  store: BotStore,
): Promise<void> {
  logger.info("Verification button received", {
    guildId: interaction.guildId,
    userId: interaction.user.id,
    messageId: interaction.message.id,
  });
  try {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    logger.info("Verification button acknowledged", {
      guildId: interaction.guildId,
      userId: interaction.user.id,
      messageId: interaction.message.id,
    });

    if (!interaction.inCachedGuild()) {
      await interaction.editReply(
        "This verification button only works in a server.",
      );
      return;
    }

    const setup = await store.getVerificationSetup(
      interaction.guildId,
      interaction.message.id,
    );
    if (!setup) {
      await interaction.editReply(
        "This verification panel is no longer active. Ask an administrator for a current panel.",
      );
      return;
    }

    if (interaction.user.bot) {
      await interaction.editReply("Bot accounts cannot use member verification.");
      return;
    }

    const botMember =
      interaction.guild.members.me ??
      (await interaction.guild.members.fetchMe());
    if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
      await interaction.editReply(
        "I need the **Manage Roles** permission to verify members. Please ask an administrator to update my permissions.",
      );
      return;
    }

    const roles = await interaction.guild.roles.fetch();
    const unverifiedRole = roles.find((role) =>
      hasRoleName(role, UNVERIFIED_ROLE_NAME),
    );
    if (!unverifiedRole) {
      await interaction.editReply(
        `This server needs a role named **${UNVERIFIED_ROLE_NAME}** before members can verify. Ask an administrator to create it.`,
      );
      return;
    }

    const existingVerifiedRole = roles.find((role) =>
      hasRoleName(role, VERIFIED_ROLE_NAME),
    );
    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member.roles.cache.has(unverifiedRole.id)) {
      await interaction.editReply(
        `Only members with the **${UNVERIFIED_ROLE_NAME}** role can use this verification panel.`,
      );
      return;
    }

    const verifiedRole = await ensureVerifiedRole(
      interaction.guild,
      setup,
      store,
      existingVerifiedRole,
    );
    if (!verifiedRole.editable || !unverifiedRole.editable || !member.manageable) {
      await interaction.editReply(
        "I can't manage the required roles for this member. Move my bot role above the **Verified** and **Un-Verified** roles, and above the member's highest role.",
      );
      return;
    }

    await member.roles.add(
      verifiedRole,
      "Member completed the server verification button",
    );
    try {
      await member.roles.remove(
        unverifiedRole,
        "Member completed the server verification button",
      );
    } catch (error) {
      logger.error("Verified role was added, but Un-Verified could not be removed", {
        guildId: interaction.guildId,
        userId: interaction.user.id,
        error: errorMessage(error),
      });
      await interaction.editReply(
        "You received the **Verified** role, but I couldn't remove **Un-Verified**. Please ask an administrator to check my role permissions.",
      );
      return;
    }

    await interaction.editReply(
      "You are now verified! Welcome to the server! 🎉",
    );
  } catch (error) {
    logger.error("Verification button failed", {
      guildId: interaction.guildId,
      userId: interaction.user.id,
      error: errorMessage(error),
    });
    const content =
      "I couldn't complete verification. Please ask an administrator to check my permissions and try again.";
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(content).catch(() => {});
    } else {
      await interaction
        .reply({ content, flags: MessageFlags.Ephemeral })
        .catch(() => {});
    }
  }
}

async function ensureVerifiedRole(
  guild: Guild,
  setup: VerificationSetup,
  store: BotStore,
  existingRole?: Role,
): Promise<Role> {
  let verifiedRole = existingRole;
  if (!verifiedRole) {
    let creation = roleCreationByGuild.get(guild.id);
    if (!creation) {
      creation = (async () => {
        const roles = await guild.roles.fetch();
        const role = roles.find((candidate) =>
          hasRoleName(candidate, VERIFIED_ROLE_NAME),
        );
        return (
          role ??
          (await guild.roles.create({
            name: VERIFIED_ROLE_NAME,
            color: GRAY_ROLE_COLOR,
            reason: "Created for the server verification system",
          }))
        );
      })();
      roleCreationByGuild.set(guild.id, creation);
    }

    try {
      verifiedRole = await creation;
    } finally {
      if (roleCreationByGuild.get(guild.id) === creation) {
        roleCreationByGuild.delete(guild.id);
      }
    }
  }

  if (setup.verifiedRoleId !== verifiedRole.id) {
    await store.setVerificationRole(
      setup.guildId,
      setup.messageId,
      verifiedRole.id,
    );
  }
  return verifiedRole;
}

function hasRoleName(role: Role, expectedName: string): boolean {
  return role.name.toLocaleLowerCase() === expectedName.toLocaleLowerCase();
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}